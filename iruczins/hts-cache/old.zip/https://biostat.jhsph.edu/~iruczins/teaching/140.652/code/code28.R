## ------------------------------------------------------------------------
# source("http://bioconductor.org/biocLite.R")
# biocLite("qvalue")
library(qvalue)

## ------------------------------------------------------------------------
set.seed(1)
p <- runif(1e5)
hist(p,breaks=101,col="lightgrey",prob=T)
abline(h=1,lwd=2,col="red")

## ------------------------------------------------------------------------
p <- c(runif(1e5),rbeta(1e3,1,1.5)/10)
hist(p,breaks=101,col="lightgrey",prob=T)
abline(h=1,lwd=2,col="red")

# Bonferroni
0.05/length(p)
min(p)

# q-values
q <- qvalue(p)
wh <- order(q$pvalues)
cbind(q$pvalues,q$qvalues)[wh,][1:20,]

## ------------------------------------------------------------------------
p <- c(runif(1e5),runif(10,0,1e-6))
hist(p,breaks=101,col="lightgrey",prob=T)
abline(h=1,lwd=2,col="red")

0.05/length(p)
min(p)

q <- qvalue(p)
wh <- order(q$pvalues)
cbind(q$pvalues,q$qvalues)[wh,][1:20,]

