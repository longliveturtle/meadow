## ------------------------------------------------------------------------
source("http://biostat.jhsph.edu/~iruczins/teaching/140.652/func/twoBinomPost.R")
x1 <- 11; n1 <- 20
x2 <- 5; n2 <- 20
twoBinomPost(x1,n1,x2,n2)

