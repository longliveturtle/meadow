
<h3><a href="index.php">A Modern Approach to Regression with R</a> &gt;> STATA - Code and Primer</h3>
                <div style="float:left;">
                <p style="text-align: center;"><img height="220" align="right" width="235" alt="Book Image" src="sheatherbook.JPG" style="float: left; width: 235px; height: 220px; margin-bottom:15px;" /></p>
       </div>
                <h4>Click to view. To save right click on link then click "Save As" or "Save Link As".</h4>
  <div style="margin-left:235px;">
  <ul style="padding-left:0px; font-weight:bold;">
  <li style='margin-bottom:5px;'><a href='docs/statacode/Stata_Code_Data_Graphics.zip'>Stata_Code_Data_Graphics.zip</a></li><li style='margin-bottom:5px;'><a href='docs/statacode/readme.txt'>readme.txt</a></li><li style='margin-bottom:5px;'><a href='docs/statacode/StataPrimer.pdf'>StataPrimer.pdf</a></li>  </ul>
    <br />
  </div>

