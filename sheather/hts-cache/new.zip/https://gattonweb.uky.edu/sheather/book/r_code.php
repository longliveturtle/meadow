
<h3><a href="index.php">A Modern Approach to Regression with R</a> &gt;> R - Code and Primer</h3>
                <div style="float:left;">
                <p style="text-align: center;"><img height="220" align="right" width="235" alt="Book Image" src="sheatherbook.JPG" style="float: left; width: 235px; height: 220px; margin-bottom:15px;" /></p>
       </div>
                <h4>Click to view. To save right click on link then click "Save As" or "Save Link As".</h4>
  <div style="margin-left:235px;">
  <ul style="padding-left:0px; font-weight:bold;">
  <li style='margin-bottom:5px;'><a href='docs/rcode/Appendix.R'>Appendix.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/R-scripts.zip'>R-scripts.zip</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter1.R'>Chapter1.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter2.R'>Chapter2.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter3.R'>Chapter3.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter4.R'>Chapter4.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter5.R'>Chapter5.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter6.R'>Chapter6.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter7.R'>Chapter7.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter8.R'>Chapter8.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter9.R'>Chapter9.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter10.R'>Chapter10.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter3NewMarch2011.R'>Chapter3NewMarch2011.R</a></li><li style='margin-bottom:5px;'><a href='docs/rcode/Chapter6NewMarch2011.R'>Chapter6NewMarch2011.R</a></li>  </ul>
    <br />
  </div>

