<!--Content Starts Here-->
<body bgcolor="#500000">
<table width="900" border="0" align="center" cellpadding="10" cellspacing="0" bgcolor = "#D9D9D9">
  <tr valign="top">
    <td colspan="3">


	<h3><a href="index.php">A Modern Approach to Regression with R</a> &gt;> Ordering Information</h3>
		<table border=0><tr><td>
                <p style="text-align: top;"><img height="220" align="right" width="235" alt="Book Image" src="sheatherbook.JPG" style="float: left; width: 235px; height: 220px; margin-bottom:15px;" /></p>
				<td>
  <br />
                <ul style="font-weight:bold;">
                <li style="margin-bottom:5px"><a href="http://www.amazon.com/Modern-Approach-Regression-Springer-Statistics/dp/0387096078" title="Order from Amazon.com">Order from Amazon.com</a>
                <li><a href="http://www.springer.com/statistics/statistical+theory+and+methods/book/978-0-387-09607-0" title="Order from Springer.com">Order from Springer.com</a>
                </ul>
  <br />
</table>
</table>
<!--Content Ends Here-->
