<html>
  <head><title>A Modern Approach to Regression with R</title></head>
  <body>
    <h3>A Modern Approach to Regression with R</h3>
    <table border=0>
      <tr>
        <td>
          <p style="text-align: center;"><img height="220" align="right" width="235" alt="Book Image" src="sheatherbook.JPG" style="float: left; width: 235px; height: 220px; margin-bottom:15px;" /></p>
        </td>
        <td>
          <ul>
            <li><strong><a href="order.php">Ordering Information</a></strong></li><br>
            <li><strong><a href="data_sets.php">Data Sets</a></strong></li><br>
            <li><strong><a href="r_code.php">R-Code</a></strong></li><br>
            <li><strong><a href="sas_code.php">SAS - Code and Primer</a></strong></li><br>
            <li><strong><a href="stata_code.php">STATA - Code and Primer</a></strong></li><br>
            <li><strong><a href="docs/Errata.pdf">Errata</a></strong></li>
          </ul>
        </td>
      </tr>
    </table>
  </body>
</html>
