
<h3><a href="index.php">A Modern Approach to Regression with R</a> &gt;> SAS - Code and Primer</h3>
                <div style="float:left;">
                <p style="text-align: center;"><img height="220" align="right" width="235" alt="Book Image" src="sheatherbook.JPG" style="float: left; width: 235px; height: 220px; margin-bottom:15px;" /></p>
       </div>
                <h4>Click to view. To save right click on link then click "Save As" or "Save Link As".</h4>
  <div style="margin-left:235px;">
  <ul style="padding-left:0px; font-weight:bold;">
  <li style='margin-bottom:5px;'><a href='docs/sascode/DataInSASFormat.zip'>DataInSASFormat.zip</a></li><li style='margin-bottom:5px;'><a href='docs/sascode/chapter1.sas'>chapter1.sas</a></li><li style='margin-bottom:5px;'><a href='docs/sascode/chapter10.sas'>chapter10.sas</a></li><li style='margin-bottom:5px;'><a href='docs/sascode/chapter2.sas'>chapter2.sas</a></li><li style='margin-bottom:5px;'><a href='docs/sascode/chapter3.sas'>chapter3.sas</a></li><li style='margin-bottom:5px;'><a href='docs/sascode/chapter4.sas'>chapter4.sas</a></li><li style='margin-bottom:5px;'><a href='docs/sascode/chapter5.sas'>chapter5.sas</a></li><li style='margin-bottom:5px;'><a href='docs/sascode/chapter6.sas'>chapter6.sas</a></li><li style='margin-bottom:5px;'><a href='docs/sascode/chapter7.sas'>chapter7.sas</a></li><li style='margin-bottom:5px;'><a href='docs/sascode/chapter8.sas'>chapter8.sas</a></li><li style='margin-bottom:5px;'><a href='docs/sascode/chapter9.sas'>chapter9.sas</a></li><li style='margin-bottom:5px;'><a href='docs/sascode/SASPrimerChapters1to10.pdf'>SASPrimerChapters1to10.pdf</a></li>  </ul>
    <br />
  </div>

