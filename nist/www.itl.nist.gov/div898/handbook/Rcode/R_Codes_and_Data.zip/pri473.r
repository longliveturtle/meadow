R commands and output:

## Read data and save relevant variables.
fname = "IMPROVE-5_4_7_3.DAT"
m = matrix(scan(fname,skip=25),ncol=7,byrow=T)
run = m[,1]
pressure = m[,2]
h2 = m[,3]
uniformity = m[,4]
stress = m[,5]
ph2 = pressure*h2
press2 = pressure*pressure
h22 = h2*h2


## Coded variables.
cpress = m[,6]
ch2 = m[,7]
cph = cpress*ch2
ch22 = ch2*ch2
cpress2 = cpress*cpress


## Create data frame.
df = data.frame(run,pressure,h2,uniformity,stress,cpress,ch2,
                ph2,press2,h22,cph,ch22,cpress2)


## Fit full model.
z = lm(uniformity ~ pressure+h2+ph2+press2+h22,data=df)
summary(z)

##> Call:
##> lm(formula = uniformity ~ pressure + h2 + ph2 + press2 + h22, 
##>     data = df)

##> Residuals:
##>       1       2       3       4       5       6       7       8       9      10 
##>  0.5125  0.3334 -0.5068  0.6068 -0.6124  0.5334  0.2886  0.1751 -0.1886 -0.2752 
##>      11 
##> -0.8666 

##> Coefficients:
##>               Estimate Std. Error t value Pr(>|t|)   
##> (Intercept)  1.137e+01  1.977e+00   5.753  0.00223 **
##> pressure    -1.252e-01  4.663e-02  -2.684  0.04361 * 
##> h2          -5.507e-01  5.082e-01  -1.084  0.32794   
##> ph2          1.118e-02  4.773e-03   2.342  0.06622 . 
##> press2       9.235e-05  4.231e-04   0.218  0.83584   
##> h22          2.088e-03  3.817e-02   0.055  0.95850   
##> ---
##> Signif. codes:  0 �***� 0.001 �**� 0.01 �*� 0.05 �.� 0.1 � � 1 

##> Residual standard error: 0.7259 on 5 degrees of freedom
##> Multiple R-squared: 0.8707,     Adjusted R-squared: 0.7415 
##> F-statistic: 6.736 on 5 and 5 DF,  p-value: 0.02823


## Perform stepwise regression.
zz = step(z,direction="both")

##> Start:  AIC=-3.72
##> uniformity ~ pressure + h2 + ph2 + press2 + h22

##>            Df Sum of Sq     RSS     AIC
##> - h22       1    0.0016  2.6362 -5.7141
##> - press2    1    0.0251  2.6597 -5.6164
##> <none>                   2.6346 -3.7207
##> - h2        1    0.6189  3.2535 -3.3997
##> - ph2       1    2.8900  5.5246  2.4245
##> - pressure  1    3.7961  6.4307  4.0950

##> Step:  AIC=-5.71
##> uniformity ~ pressure + h2 + ph2 + press2

##>            Df Sum of Sq     RSS     AIC
##> - press2    1    0.0236  2.6598 -7.6162
##> <none>                   2.6362 -5.7141
##> + h22       1    0.0016  2.6346 -3.7207
##> - ph2       1    2.8900  5.5262  0.4277
##> - h2        1    3.0077  5.6439  0.6595
##> - pressure  1    3.9601  6.5963  2.3748

##> Step:  AIC=-7.62
##> uniformity ~ pressure + h2 + ph2

##>            Df Sum of Sq     RSS     AIC
##> <none>                   2.6598 -7.6162
##> + press2    1    0.0236  2.6362 -5.7141
##> + h22       1    0.0001  2.6597 -5.6164
##> - ph2       1    2.8900  5.5498 -1.5255
##> - h2        1    3.0077  5.6675 -1.2946
##> - pressure  1    7.9682 10.6280  5.6216


## generate ANOVA table for selected model
anova(update(zz,~1),zz)

##> Analysis of Variance Table

##> Model 1: uniformity ~ 1
##> Model 2: uniformity ~ pressure + h2 + ph2
##>   Res.Df     RSS Df Sum of Sq      F   Pr(>F)   
##> 1     10 20.3818                                
##> 2      7  2.6598  3   17.7220 15.547 0.001772 **
##> ---
##> Signif. codes:  0 �***� 0.001 �**� 0.01 �*� 0.05 �.� 0.1 � � 1 


summary(zz)

##> Call:
##> lm(formula = uniformity ~ pressure + h2 + ph2, data = df)

##> Residuals:
##>     Min      1Q  Median      3Q     Max 
##> -0.9273 -0.3932  0.1479  0.3920  0.6295 

##> Coefficients:
##>              Estimate Std. Error t value Pr(>|t|)    
##> (Intercept) 11.195193   1.186352   9.437 3.13e-05 ***
##> pressure    -0.117395   0.025636  -4.579  0.00255 ** 
##> h2          -0.525696   0.186849  -2.813  0.02602 *  
##> ph2          0.011178   0.004053   2.758  0.02818 *  
##> ---
##> Signif. codes:  0 �***� 0.001 �**� 0.01 �*� 0.05 �.� 0.1 � � 1 

##> Residual standard error: 0.6164 on 7 degrees of freedom
##> Multiple R-squared: 0.8695,     Adjusted R-squared: 0.8136 
##> F-statistic: 15.55 on 3 and 7 DF,  p-value: 0.001772


## Generate ANOVA table.
anova(zz)

##> Analysis of Variance Table

##> Response: uniformity
##>           Df  Sum Sq Mean Sq F value    Pr(>F)    
##> pressure   1 14.6296 14.6296 38.5022 0.0004431 ***
##> h2         1  0.2024  0.2024  0.5326 0.4891950    
##> ph2        1  2.8900  2.8900  7.6059 0.0281821 *  
##> Residuals  7  2.6598  0.3800                      
##> ---
##> Signif. codes:  0 �***� 0.001 �**� 0.01 �*� 0.05 �.� 0.1 � � 1 


## Perform lack-of-fit test.
lof = factor(paste(pressure,h2,ph2))
inner.model = lm(uniformity ~ pressure + h2 + ph2, data = df)
outer.model = lm(uniformity ~ lof)
anova(inner.model, outer.model)

##> Analysis of Variance Table

##> Model 1: uniformity ~ pressure + h2 + ph2
##> Model 2: uniformity ~ lof
##>   Res.Df    RSS Df Sum of Sq      F Pr(>F)
##> 1      7 2.6598                           
##> 2      2 1.1467  5    1.5131 0.5278 0.7559


## Plot actual versus predicted.
par(mfrow=c(1,1),bg=rgb(1,1,0.8))
plot(predict(zz),df$uniformity,ylab="Observed Uniformity",
     xlab="Predicted Uniformity", col=4, pch=19)
## Add regression line and confidence bounds to the plot.
rline = lm(predict(zz)~df$uniformity)
abline(rline)
bnds = data.frame(predict.lm(rline, interval = "confidence"),uniformity)
bnds = bnds[order(bnds$fit),]
lines(bnds$uniformity,bnds[,2],col=2)
lines(bnds$uniformity,bnds[,3],col=2)
par(mfrow=c(1,1))


## Generate normal probability plot of the effects.
## Save parameters in a vector, but remove intercept.
qef = z$coef
qef = qef[-1]

## Sort effects and save labels.
sef = qef[order(qef)]
qlab = names(sef)
qlab=c("H2/WF6","Press","Press^2","H2/WF6^2","Press*H2/WF6")

## Generate theoretical quantiles.
ip = ppoints(length(sef))
zp = qnorm(ip)

## Generate normal probability plot of all effects (excluding the
## intercept).  
par(mfrow=c(1,1),bg=rgb(1,1,0.8))
plot(zp, sef, pch=19,
     ylab="Parameter Estimate", xlab="Theoretical Quantiles",
     main="Normal Probability Plot of Parameter Estimates")
##qqline(sef, col=2)
##abline(h=0, col=4)

## Add labels for effects.
small2 = c(1:(length(sef)-3))
text(zp[small2],sef[small2],label=qlab[small2],pos=4,cex=1)
text(zp[-small2],sef[-small2],label=qlab[-small2],pos=2,cex=1)


## Generate interaction plots.
dfp = subset(df,pressure==15.13|pressure==68.87)

par(mfrow=c(2,1), bg=rgb(1,1,0.8), mar=c(5, 8, 2, 4))
interaction.plot(dfp$h2, dfp$pressure, dfp$uniformity, fun=mean,
                 type="b", pch=c(21,21), col=4,
                 xlab="H2/W6", ylab="Uniformity", trace.lab="Pressure")

interaction.plot(dfp$pressure, dfp$h2, dfp$uniformity, fun=mean,
                 type="b", pch=c(21,21), col=4,
                 trace.lab="H2/W6", ylab="Uniformity", xlab="Pressure")


## Generate x and y data for plotting.
xord = seq(4,80,by=4)
yord = seq(2,10,by=.5)

## Generate predicted response surface and generate matrix of surface.
model = function (a, b){
  zz$coefficients[1] +
  zz$coefficients[2]*a +
  zz$coefficients[3]*b +
  zz$coefficients[4]*a*b}
pmatu = outer(xord,yord,model)


## Generate contour plot.
par(mfrow=c(1,1), bg=rgb(1,1,0.8))
contour(xord, yord, pmatu, nlevels=30, xlab="Pressure", ylab="H2/WF6",
        col="blue")
par(mfrow=c(1,1))


## Generate perspective plot.
par(mfrow=c(1,1), bg=rgb(1,1,0.8))
persp(xord, yord, pmatu, xlab="Pressure", ylab="H2/WF6", zlab="Uniformity",
      theta=30, phi=30, ticktype="detailed", col="lightblue") 
par(mfrow=c(1,1))


## Generate four plots of residuals.
par(mfrow=c(2,2), bg=rgb(1,1,0.8))
qqnorm(zz$residuals)
qqline(zz$residuals, col = 2)
abline(h=0)
boxplot(zz$residuals, horizontal=TRUE, main="Box Plot", xlab="Residual")
hist(zz$residuals, main="Histogram", xlab="Residual")
plot(run, zz$residuals, xlab="Actual Run Order", ylab="Residual",
     main="Run Order Plot", col=4, pch=19)
par(mfrow=c(1,1))


## Fit model
q = lm(stress ~ pressure+h2+ph2+press2+h22,data=df)
summary(q)

##> Call:
##> lm(formula = stress ~ pressure + h2 + ph2 + press2 + h22, data = df)

##> Residuals:
##>         1         2         3         4         5         6         7         8 
##>  0.042447 -0.010004 -0.019295  0.009363 -0.032516 -0.100004  0.033712 -0.012256 
##>         9        10        11 
##> -0.043644  0.022198  0.109996 

##> Coefficients:
##>               Estimate Std. Error t value Pr(>|t|)    
##> (Intercept)  5.427e+00  2.081e-01  26.073 1.55e-06 ***
##> pressure     4.748e-02  4.909e-03   9.671 0.000201 ***
##> h2           1.951e-01  5.350e-02   3.646 0.014803 *  
##> ph2          4.603e-04  5.025e-04   0.916 0.401714    
##> press2      -3.670e-04  4.454e-05  -8.240 0.000429 ***
##> h22         -7.498e-03  4.019e-03  -1.866 0.121067    
##> ---
##> Signif. codes:  0 �***� 0.001 �**� 0.01 �*� 0.05 �.� 0.1 � � 1 

##> Residual standard error: 0.07642 on 5 degrees of freedom
##> Multiple R-squared: 0.9919,     Adjusted R-squared: 0.9838 
##> F-statistic: 122.3 on 5 and 5 DF,  p-value: 3.192e-05 


## Perform stepwise regression.
stepq = step(q,direction="both")

##> Start:  AIC=-53.25
##> stress ~ pressure + h2 + ph2 + press2 + h22

##>            Df Sum of Sq     RSS     AIC
##> - ph2       1     0.005   0.034 -53.539
##> <none>                    0.029 -53.245
##> - h22       1     0.020   0.050 -49.433
##> - h2        1     0.078   0.107 -40.975
##> - press2    1     0.397   0.426 -25.769
##> - pressure  1     0.546   0.575 -22.455

##> Step:  AIC=-53.54
##> stress ~ pressure + h2 + press2 + h22

##>            Df Sum of Sq     RSS     AIC
##> <none>                    0.034 -53.539
##> + ph2       1     0.005   0.029 -53.245
##> - h22       1     0.020   0.054 -50.395
##> - h2        1     0.111   0.145 -39.602
##> - press2    1     0.397   0.431 -27.643
##> - pressure  1     0.982   1.016 -18.200

qq = lm(stress ~ pressure+h2+press2,data=df)

anova(qq,q)

##> Analysis of Variance Table

##> Model 1: stress ~ pressure + h2 + press2
##> Model 2: stress ~ pressure + h2 + ph2 + press2 + h22
##>   Res.Df      RSS Df Sum of Sq      F Pr(>F)
##> 1      7 0.054435                           
##> 2      5 0.029203  2  0.025232 2.1601 0.2108


# ANOVA for reduced model for stress
anova(update(qq,~1),qq)

##> Analysis of Variance Table

##> Model 1: stress ~ 1
##> Model 2: stress ~ pressure + h2 + press2
##>   Res.Df    RSS Df Sum of Sq      F   Pr(>F)    
##> 1     10 3.6001                                 
##> 2      7 0.0544  3    3.5456 151.98 9.84e-07 ***
##> ---
##> Signif. codes:  0 �***� 0.001 �**� 0.01 �*� 0.05 �.� 0.1 � � 1

summary(qq)

##> Call:
##> lm(formula = stress ~ pressure + h2 + press2, data = df)

##> Residuals:
##>      Min       1Q   Median       3Q      Max 
##> -0.07576 -0.04519 -0.02985  0.04699  0.16647 

##> Coefficients:
##>               Estimate Std. Error t value Pr(>|t|)    
##> (Intercept)  5.567e+00  1.056e-01  52.706 2.32e-10 ***
##> pressure     4.819e-02  4.286e-03  11.241 9.84e-06 ***
##> h2           1.244e-01  1.102e-02  11.293 9.55e-06 ***
##> press2      -3.426e-04  4.912e-05  -6.974 0.000217 ***
##> ---
##> Signif. codes:  0 �***� 0.001 �**� 0.01 �*� 0.05 �.� 0.1 � � 1 

##> Residual standard error: 0.08818 on 7 degrees of freedom
##> Multiple R-squared: 0.9849,     Adjusted R-squared: 0.9784 
##> F-statistic:   152 on 3 and 7 DF,  p-value: 9.84e-07 

## Generate anova table.
anova(qq)

##> Analysis of Variance Table

##> Response: stress
##>           Df  Sum Sq Mean Sq F value    Pr(>F)    
##> pressure   1 2.17573 2.17573 279.783 6.676e-07 ***
##> h2         1 0.99166 0.99166 127.521 9.550e-06 ***
##> press2     1 0.37822 0.37822  48.637 0.0002165 ***
##> Residuals  7 0.05444 0.00778                      
##> ---
##> Signif. codes:  0 �***� 0.001 �**� 0.01 �*� 0.05 �.� 0.1 � � 1

## Perform lack-of-fit test.
lof = factor(paste(pressure,h2,ph2))
inner.model = lm(stress ~ pressure + h2 + press2, data = df)
outer.model = lm(stress ~ lof)
anova(inner.model, outer.model)

##> Analysis of Variance Table

##> Model 1: stress ~ pressure + h2 + press2
##> Model 2: stress ~ lof
##>   Res.Df      RSS Df Sum of Sq      F Pr(>F)
##> 1      7 0.054435                           
##> 2      2 0.022200  5  0.032235 0.5808 0.7301

## Plot actual versus predicted.
par(mfrow=c(1,1), bg=rgb(1,1,0.8))
plot(predict(qq),df$stress,ylab="Observed Stress",
     xlab="Predicted Stress", pch=19, col=4)
## Add regression line and confidence bounds to the plot.
rline = lm(predict(qq)~df$stress)
abline(rline)
bnds = data.frame(predict.lm(rline, interval = "confidence"), stress)
bnds = bnds[order(bnds$fit),]
lines(bnds$stress,bnds[,2], col=2)
lines(bnds$stress,bnds[,3], col=2)
par(mfrow=c(1,1))


## Generate normal probability plot of the effects.
## Save parameters in a vector, but remove intercept.
qef = q$coef
qef = qef[-1]

## Sort effects and save labels.
sef = qef[order(qef)]
qlab = names(sef)
qlab=c("H2/WF6^2","Press^2","Press*H2/WF6","Press","H2/WF6")

## Generate theoretical quantiles.
ip = ppoints(length(sef))
zp = qnorm(ip)

## Generate normal probability plot of all effects (excluding the
## intercept).  
par(mfrow=c(1,1),bg=rgb(1,1,0.8))
plot(zp, sef, pch=19,
     ylab="Parameter Estimate", xlab="Theoretical Quantiles",
     main="Normal Probability Plot of Parameter Estimates")
## Add labels for effects.
small2 = c(1:(length(sef)-2))
text(zp[small2],sef[small2],label=qlab[small2],pos=4,cex=1)
text(zp[-small2],sef[-small2],label=qlab[-small2],pos=2,cex=1)
par(mfrow=c(1,1))


## Generate interaction plots.
dfp = subset(df,pressure==15.13|pressure==68.87)

par(mfrow=c(2,1), bg=rgb(1,1,0.8), mar=c(5, 8, 2, 4))
interaction.plot(dfp$h2, dfp$pressure, dfp$stress, fun=mean,
                 type="b", pch=c(21,21), col=2,
                 xlab="H2/W6", ylab="Stress", trace.lab="Pressure")

interaction.plot(dfp$pressure, dfp$h2, dfp$stress, fun=mean,
                 type="b", pch=c(21,21), col=2,
                 trace.lab="H2/W6", ylab="Stress", xlab="Pressure")
par(mfrow=c(1,1), mar=c(5, 4, 4, 2)+0.1)


## Generate x and y data for plotting.
xord = seq(4,80,by=4)
yord = seq(2,10,by=.5)

## Generate predicted response surface and generate matrix of surface.
model = function (a, b){
  qq$coefficients[1] +
  qq$coefficients[2]*a +
  qq$coefficients[3]*b +
  qq$coefficients[4]*a*a}
pmats = outer(xord,yord,model)


## Generate contour plot.
par(mfrow=c(1,1), bg=rgb(1,1,0.8))
contour(xord, yord, pmats, nlevels=30, xlab="Pressure", ylab="H2/WF6",
        col="red")
par(mfrow=c(1,1))


## Generate perspective plot.
par(mfrow=c(1,1), bg=rgb(1,1,0.8))
persp(xord, yord, pmats, xlab="Pressure", ylab="H2/WF6", zlab="Stress",
      theta=30, phi=30, ticktype="detailed", col="lightblue") 
par(mfrow=c(1,1))


## Generate four plots of residuals.
par(mfrow=c(2,2), bg=rgb(1,1,0.8))
qqnorm(qq$residuals)
qqline(qq$residuals, col = 2)
abline(h=0)
boxplot(qq$residuals, horizontal=TRUE, main="Box Plot", xlab="Residual")
hist(qq$residuals, main="Histogram", xlab="Residual")
plot(run, qq$residuals, xlab="Actual Run Order", ylab="Residual",
     main="Run Order Plot", pch=19, col=4)
par(mfrow=c(1,1))


## Overlay uniformity and stress contour plots.
par(mfrow=c(1,1), bg=rgb(1,1,0.8))
contour(xord, yord, pmatu, nlevels=20, xlab="Pressure", ylab="H2/WF6",
        col="blue")
contour(xord, yord, pmats, nlevels=15, xlab="Pressure", ylab="H2/WF6",
        col="red",add=TRUE)
par(mfrow=c(1,1))

