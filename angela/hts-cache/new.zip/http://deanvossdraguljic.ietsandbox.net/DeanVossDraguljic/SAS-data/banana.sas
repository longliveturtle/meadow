* banana.sas, banana experiment, Example 10.8.1, Table 10.11, p326;
;
* Data as arranged in Table 10.11;
data banana;
  input block light storage @@;
  do rep=1 to 4; drop rep;
    input y @@;
    output;
  end;
  lines;
  1 1 1 30 30 17 43
  1 1 2 43 35 36 64
  1 2 1 37 38 23 53
  1 2 2 22 35 30 38
  2 1 1 49 60 41 61
  2 1 2 57 46 31 34
  2 2 1 20 63 64 34
  2 2 2 40 47 62 42
  3 1 1 21 45 38 39
  3 1 2 42 13 21 26
  3 2 1 41 74 24 51
  3 2 2 38 22 31 55
;
* Data by observation;
data banana;
  input block light storage  y;
  lines;
          1     1      1    30
          1     1      1    30
          1     1      1    17
          1     1      1    43
          1     1      2    43
          1     1      2    35
          1     1      2    36
          1     1      2    64
          1     2      1    37
          1     2      1    38
          1     2      1    23
          1     2      1    53
          1     2      2    22
          1     2      2    35
          1     2      2    30
          1     2      2    38
          2     1      1    49
          2     1      1    60
          2     1      1    41
          2     1      1    61
          2     1      2    57
          2     1      2    46
          2     1      2    31
          2     1      2    34
          2     2      1    20
          2     2      1    63
          2     2      1    64
          2     2      1    34
          2     2      2    40
          2     2      2    47
          2     2      2    62
          2     2      2    42
          3     1      1    21
          3     1      1    45
          3     1      1    38
          3     1      1    39
          3     1      2    42
          3     1      2    13
          3     1      2    21
          3     1      2    26
          3     2      1    41
          3     2      1    74
          3     2      1    24
          3     2      1    51
          3     2      2    38
          3     2      2    22
          3     2      2    31
          3     2      2    55
;       
run;
