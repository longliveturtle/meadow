* weight.lifting.sas, weight lifting experiment, Table 6.21, p193;
;
* Data as arranged in Table 6.21;
* Merged into data set weightlifting, below;
data wtA (keep = A) wtB (keep = B) wtR (keep = rate);
  do rowsection=1 to 6;
    do col=1 to 11; input A @@; output wtA; end;
	do col=1 to 11; input B @@; output wtB; end;
	do col=1 to 11; input rate @@; output wtR; end;
  end;
lines;
   2   1   1   1   2   2   1   2   1   2   1
   2   1   3   1   2   3   3   2   2   2   1
  31  27  37  28  32  32  35  30  32  31  27
   2   1   1   1   2   1   1   2   2   2   2
   2   3   3   2   1   1   3   1   3   3   3
  34  33  34  31  26  25  35  24  33  31  36
   1   1   1   1   1   1   1   1   2   1   2
   3   1   1   2   1   2   2   3   3   2   1
  36  27  30  33  29  32  34  37  32  34  27
   2   1   1   2   2   1   1   2   2   1   2
   2   1   3   1   2   1   2   1   2   1   3
  31  27  38  27  30  29  34  25  34  28  34
   2   1   2   1   1   2   1   1   2   2   2
   2   1   3   2   2   1   3   2   1   1   1
  31  30  34  35  34  24  35  31  27  26  25
   2   2   2   1   2   2   2   2   2   1   1
   2   3   1   2   1   2   3   3   3   3   3
  32  35  24  33  23  30  34  32  33  37  38
;
data weightlifting; merge wtA wtB wtR; order=_n_;
;
* Data by observation;
data weightlifting;
  input order A B rate;
  lines;
          1   2 2  31
          2   1 1  27
          3   1 3  37
          4   1 1  28
          5   2 2  32
          6   2 3  32
          7   1 3  35
          8   2 2  30
          9   1 2  32
         10   2 2  31
         11   1 1  27
         12   2 2  34
         13   1 3  33
         14   1 3  34
         15   1 2  31
         16   2 1  26
         17   1 1  25
         18   1 3  35
         19   2 1  24
         20   2 3  33
         21   2 3  31
         22   2 3  36
         23   1 3  36
         24   1 1  27
         25   1 1  30
         26   1 2  33
         27   1 1  29
         28   1 2  32
         29   1 2  34
         30   1 3  37
         31   2 3  32
         32   1 2  34
         33   2 1  27
         34   2 2  31
         35   1 1  27
         36   1 3  38
         37   2 1  27
         38   2 2  30
         39   1 1  29
         40   1 2  34
         41   2 1  25
         42   2 2  34
         43   1 1  28
         44   2 3  34
         45   2 2  31
         46   1 1  30
         47   2 3  34
         48   1 2  35
         49   1 2  34
         50   2 1  24
         51   1 3  35
         52   1 2  31
         53   2 1  27
         54   2 1  26
         55   2 1  25
         56   2 2  32
         57   2 3  35
         58   2 1  24
         59   1 2  33
         60   2 1  23
         61   2 2  30
         62   2 3  34
         63   2 3  32
         64   2 3  33
         65   1 3  37
         66   1 3  38
;
run;
