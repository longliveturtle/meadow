* spaghetti.sauce.sas, spaghetti sauce experiment, Table 5.22, p137;
;
data spaghetti;
  input order trtmt weight brand stir;
  lines;
           1    3     14     2     1
           2    2     69     1     2
           3    4     26     2     2
           4    3     15     2     1
           5    4     20     2     2
           6    5     12     3     1
           7    1     55     1     1
           8    6     14     3     2
           9    6     16     3     2
          10    5     16     3     1
          11    1     66     1     1
          12    2     64     1     2
          13    4     23     2     2
          14    6     17     3     2
          15    3     22     2     1
          16    5     18     3     1
          17    2     64     1     2
          18    1     53     1     1
;
run;