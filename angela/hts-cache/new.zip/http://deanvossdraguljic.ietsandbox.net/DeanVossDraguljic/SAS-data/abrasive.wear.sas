* abrasive.wear.sas, abrasive wear experiment, Table 7.24, p245;
;
data abrasive;
  input A B C   y;
  lines;
        1 1 1 0.049
        1 1 2 0.041
        1 2 1 0.220
        1 2 2 0.358
        2 1 1 0.044
        2 1 2 0.030
        2 2 1 0.133
        2 2 2 0.192
;
run;
