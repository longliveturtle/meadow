* dessert.sas, dessert experiment, Table 5.20, p136;
;
data dessert;
  input position trtmt pctmelt salt sugar;
  lines;
            1      2      1      2  12.06
            2      5      2      2   9.66
            3      5      2      2   7.96
            4      1      1      1   9.04
            5      4      2      1  10.17
            6      3      1      3   7.86
            7      4      2      1   8.14
            8      1      1      1   9.52
            9      3      1      3   4.28
           10      1      1      1   8.32
           11      2      1      2  10.74
           12      4      2      1   5.98
           13      2      1      2   9.84
           14      6      2      3   7.58
           15      6      2      3   6.65
           16      3      1      3   9.26
           17      6      2      3   8.46
           18      5      2      2  12.83
;
run;
