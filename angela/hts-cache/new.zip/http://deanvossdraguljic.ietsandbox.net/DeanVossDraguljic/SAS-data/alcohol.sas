* alcohol.sas, alcohol experiment, Table 17.19, p665;
;
* Data as arranged in Table 17.19, p665;
data alcohol;
  input bottle @@; 
  do eu=1 to 4; drop eu;
    input conc @@;
    output;
  end;
  lines;
  1  1.4357 1.4348 1.4336 1.4309
  2  1.4244 1.4232 1.4213 1.4256
  3  1.4153 1.4137 1.4176 1.4164
  4  1.4331 1.4325 1.4312 1.4297
  5  1.4252 1.4261 1.4293 1.4272
  6  1.4179 1.4217 1.4191 1.4204
;
* Data by observation;
data alcohol;
  input bottle  conc;
  lines;
          1    1.4357
          1    1.4348
          1    1.4336
          1    1.4309
          2    1.4244
          2    1.4232
          2    1.4213
          2    1.4256
          3    1.4153
          3    1.4137
          3    1.4176
          3    1.4164
          4    1.4331
          4    1.4325
          4    1.4312
          4    1.4297
          5    1.4252
          5    1.4261
          5    1.4293
          5    1.4272
          6    1.4179
          6    1.4217
          6    1.4191
          6    1.4204
;
run;
