* margarine.sas, margarine experiment, Table 5.16, p133;
;
* Data as arranged in Table 5.16;
data margarine;
  input brand @@;
  do rep=1 to 10;
    input time @@;
	output;
  end;
  lines;
  1 167 171 178 175 184 176 185 172 178 178 
  2 231 233 236 252 233 225 241 248 239 248 
  3 176 168 171 172 178 176 169 164 169 171 
  4 201 199 196 211 209 223 209 219 212 210 
;
* Data by observation;
data margarine;
  input brand time;
  lines;
          1    167
          1    171
          1    178
          1    175
          1    184
          1    176
          1    185
          1    172
          1    178
          1    178
          2    231
          2    233
          2    236
          2    252
          2    233
          2    225
          2    241
          2    248
          2    239
          2    248
          3    176
          3    168
          3    171
          3    172
          3    178
          3    176
          3    169
          3    164
          3    169
          3    171
          4    201
          4    199
          4    196
          4    211
          4    209
          4    223
          4    209
          4    219
          4    212
          4    210
;
run;
