* sugar.beet3.sas, sugar beet experiment, Table 15.52, p551;
;
data sugarbeet3;
  input trtmt $ N P K yield;
  lines;
         202    2 0 2  2189
         020    0 2 0  2093
         210    2 1 0  2354
         111    1 1 1  2268
         001    0 0 1  1926
         122    1 2 2  2152
         221    2 2 1  2349
         012    0 1 2  2025
         100    1 0 0  2106
;
run;
