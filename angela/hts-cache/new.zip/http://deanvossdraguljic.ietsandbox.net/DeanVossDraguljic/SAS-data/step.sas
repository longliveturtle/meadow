* step.sas, step experiment, Table 11.15, p373;
;
* Data as arranged in Table 11.15;
data step;
  input block @@;
  do trtmt = '11', '12', '13', '21', '22', '23';
    C=substr(trtmt,1,1); D=substr(trtmt,2,1);
    input y @@;
	if y ne . then output;
  end;
  lines;
  1   .  75  87  84  93  99
  2  93  84  96  90 108   . 
  3  99  93  96   . 123 129
  4  99 108  99  99   . 120
  5  99   . 111  90 129 141
  6 129 135   . 120 147 153
;
* Data by observation;
data step;
  input block trtmt C D   y;
  lines;
          1     12  1 2  75
          1     13  1 3  87
          1     21  2 1  84
          1     22  2 2  93
          1     23  2 3  99
          2     11  1 1  93
          2     12  1 2  84
          2     13  1 3  96
          2     21  2 1  90
          2     22  2 2 108
          3     11  1 1  99
          3     12  1 2  93
          3     13  1 3  96
          3     22  2 2 123
          3     23  2 3 129
          4     11  1 1  99
          4     12  1 2 108
          4     13  1 3  99
          4     21  2 1  99
          4     23  2 3 120
          5     11  1 1  99
          5     13  1 3 111
          5     21  2 1  90
          5     22  2 2 129
          5     23  2 3 141
          6     11  1 1 129
          6     12  1 2 135
          6     21  2 1 120
          6     22  2 2 147
          6     23  2 3 153
;
run;
