* catalytic.reaction.sas, catalytic reaction experiment, Table 13.28, p470;
;
* Data as arranged in Table 13.28;
data cat;
  input run block TC $ y @@;
    A=substr(TC,1,1);
    B=substr(TC,2,1);
    C=substr(TC,3,1);
  output;
  lines;
  1 1 011 89.5   9 3 010 86.2
  2 1 101 84.2  10 3 100 81.8
  3 1 110 85.2  11 3 001 90.4
  4 1 000 89.9  12 3 111 83.6
  5 2 010 85.1  13 4 110 75.3
  6 2 111 83.5  14 4 000 84.6
  7 2 001 90.8  15 4 011 86.7  
  8 2 100 81.8  16 4 101 82.2
;
* Data by observation;
data cat;
  input run block A B C    y;
  lines;
         1    1   0 1 1  89.5
         2    1   1 0 1  84.2
         3    1   1 1 0  85.2
         4    1   0 0 0  89.9
         5    2   0 1 0  85.1
         6    2   1 1 1  83.5
         7    2   0 0 1  90.8
         8    2   1 0 0  81.8
         9    3   0 1 0  86.2
        10    3   1 0 0  81.8
        11    3   0 0 1  90.4
        12    3   1 1 1  83.6
        13    4   1 1 0  75.3
        14    4   0 0 0  84.6
        15    4   0 1 1  86.7
        16    4   1 0 1  82.2
;
run;
