* plasma.sas, plasma experiment, Table 11.11, p368;
;
* Data as arranged in Table 11.11;
data plasma;
  do block=1 to 6;
    do rep=1 to 3; drop rep;
      input y trtmt @@;
      output;
  end; end;
  lines;
  0.482 1  0.459 4  0.458 5 
  0.464 2  0.465 5  0.467 6 
  0.473 3  0.472 6  0.495 1 
  0.283 4  0.325 1  0.296 2 
  0.410 5  0.390 2  0.248 3 
  0.384 6  0.239 3  0.350 4 
;
* Data by observtion;
data plasma;
  input block trtmt   y;
  lines;
          1     1   0.482
          1     4   0.459
          1     5   0.458
          2     2   0.464
          2     5   0.465
          2     6   0.467
          3     3   0.473
          3     6   0.472
          3     1   0.495
          4     4   0.283
          4     1   0.325
          4     2   0.296
          5     5   0.410
          5     2   0.390
          5     3   0.248
          6     6   0.384
          6     3   0.239
          6     4   0.350
;
run;
