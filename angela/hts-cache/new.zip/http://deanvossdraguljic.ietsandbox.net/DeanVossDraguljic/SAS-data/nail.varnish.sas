* nail.varnish.sas, nail varnish experiment, Table 6.6, p162;
;
* Data as in Table 6.6;
data nv1 nv2 nv3;
  do row=1 to 3; drop = row;
    do subrow=1 to 8; input solvent @@; output nv1; end;
    do subrow=1 to 8; input varnish @@; output nv2; end;
    do subrow=1 to 8; input time @@;    output nv3; end;
  end;
  row=4;
  do subrow=1 to 6; input solvent @@; output nv1; end;
  do subrow=1 to 6; input varnish @@; output nv2; end;
  do subrow=1 to 6; input time @@;    output nv3; end;
  lines;
  2 1 1 2 2 2 1 2
  3 3 3 3 2 2 2 2
  32.50 30.20 27.25 24.25 34.42 26.00 22.50 31.08
  1 2 1 1 2 1 2 2
  2 1 1 1 1 3 3 2
  25.17 29.17 27.58 28.75 31.75 29.75 30.75 29.17
  1 1 2 1 2 2 1 2
  2 1 2 2 1 3 3 1
  27.75 25.83 24.75 21.50 32.08 29.50 24.50 28.50
  2 1 1 2 1 1
  3 3 1 1 1 2
  28.75 22.75 29.25 31.25 22.08 25.00  
;
data nailvarnish; merge nv1 (keep=solvent) nv2 (keep=varnish) nv3 (keep=time);
  trtmt=10*solvent+varnish;
  order = _n_;
;
* Data by observation;
data nailpolish;
  input order solvent varnish trtmt time;
  lines;
          1      2       3     23   32.50
          2      1       3     13   30.20
          3      1       3     13   27.25
          4      2       3     23   24.25
          5      2       2     22   34.42
          6      2       2     22   26.00
          7      1       2     12   22.50
          8      2       2     22   31.08
          9      1       2     12   25.17
         10      2       1     21   29.17
         11      1       1     11   27.58
         12      1       1     11   28.75
         13      2       1     21   31.75
         14      1       3     13   29.75
         15      2       3     23   30.75
         16      2       2     22   29.17
         17      1       2     12   27.75
         18      1       1     11   25.83
         19      2       2     22   24.75
         20      1       2     12   21.50
         21      2       1     21   32.08
         22      2       3     23   29.50
         23      1       3     13   24.50
         24      2       1     21   28.50
         25      2       3     23   28.75
         26      1       3     13   22.75
         27      1       1     11   29.25
         28      2       1     21   31.25
         29      1       1     11   22.08
         30      1       2     12   25.00
;
run;