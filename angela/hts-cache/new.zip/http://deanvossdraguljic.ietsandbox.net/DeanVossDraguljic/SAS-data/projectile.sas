* projectile.sas, projectile experiment, Table 13.23, p465;
;
* Data as arranged in Table 13.23;
data projectile;
  do day=1 to 2;
    input run TC $ y @@;
	A=substr(TC,1,1); B=substr(TC,2,1); 
	C=substr(TC,3,1); D=substr(TC,4,1); 
	output;
  end;
  lines;
  1 0000  97    13 0001  75
  7 0011  26    11 0010  39
  5 0101  53     9 0100  68
  3 0110  15    15 0111 -16
  6 1001 145    10 1000 151
  4 1010 100    16 1011  97
  2 1100 150    14 1101 141
  8 1111  54    12 1110  66
;
* Data by observation, sorted by day;
data projectile;
  input day run  TC  A B C D  y;
  lines;
         1    1 0000 0 0 0 0  97
         1    7 0011 0 0 1 1  26
         1    5 0101 0 1 0 1  53
         1    3 0110 0 1 1 0  15
         1    6 1001 1 0 0 1 145
         1    4 1010 1 0 1 0 100
         1    2 1100 1 1 0 0 150
         1    8 1111 1 1 1 1  54
         2   13 0001 0 0 0 1  75
         2   11 0010 0 0 1 0  39
         2    9 0100 0 1 0 0  68
         2   15 0111 0 1 1 1 -16
         2   10 1000 1 0 0 0 151
         2   16 1011 1 0 1 1  97
         2   14 1101 1 1 0 1 141
         2   12 1110 1 1 1 0  66
;
run;
