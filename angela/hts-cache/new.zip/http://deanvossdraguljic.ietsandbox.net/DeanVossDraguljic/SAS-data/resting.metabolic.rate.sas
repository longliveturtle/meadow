* resting.metabolic.rate.sas, resting metabolic rate experiment, Table 10.3, p312;
;
* Data as arranged in Table 10.3;
data resting;
  input subject @@;
  do protocol=1 to 3;
    input rate @@;
	output;
  end;
  lines;
  1  7131  6846  7095
  2  8062  8573  8685
  3  6921  7287  7132
  4  7249  7554  7471
  5  9551  8866  8840
  6  7046  7681  6939
  7  7715  7535  7831
  8  9862 10087  9711
  9  7812  7708  8179
;
* Data by observation;
data resp;
  input subject protocol rate;
  lines;
           1        1    7131
           1        2    6846
           1        3    7095
           2        1    8062
           2        2    8573
           2        3    8685
           3        1    6921
           3        2    7287
           3        3    7132
           4        1    7249
           4        2    7554
           4        3    7471
           5        1    9551
           5        2    8866
           5        3    8840
           6        1    7046
           6        2    7681
           6        3    6939
           7        1    7715
           7        2    7535
           7        3    7831
           8        1    9862
           8        2   10087
           8        3    9711
           9        1    7812
           9        2    7708
           9        3    8179
;
run;