* video.game.sas, video game experiment, Table 12.16, p426;
;
* Data as arranged in Table 12.16;
data videogame;
  input order @@;
  do day=1 to 5;
    input trtmt y @@;
	output;
  end;
  lines;
  1   1  94   3 100   4  98   2 101   5 112
  2   3 103   2 111   1  51   5 110   4  90
  3   4 114   1  75   5  94   3  85   2 107
  4   5 100   4  74   2  70   1  93   3 106
  5   2 106   5  95   3  81   4  90   1  73
;
* Data by observation, sorted by day and order;
data videogame;
  input order day trtmt  y; 
  lines;
          1    1    1   94
          1    2    3  103
          1    3    4  114
          1    4    5  100
          1    5    2  106
          2    1    3  100
          2    2    2  111
          2    3    1   75
          2    4    4   74
          2    5    5   95
          3    1    4   98
          3    2    1   51
          3    3    5   94
          3    4    2   70
          3    5    3   81
          4    1    2  101
          4    2    5  110
          4    3    3   85
          4    4    1   93
          4    5    4   90
          5    1    5  112
          5    2    4   90
          5    3    2  107
          5    4    3  106
          5    5    1   73
;
run;