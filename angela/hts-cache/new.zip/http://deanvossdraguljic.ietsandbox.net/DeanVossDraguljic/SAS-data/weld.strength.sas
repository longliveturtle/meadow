* weld.strength.sas, weld strength experiment, Table 6.22, p195;
;
* Data as arranged in Table 6.22;
data weldstrength;
  input gage @@;
  do time=1 to 5;
    trtmt = 10*gage + time;
    do rep=1 to 2; drop rep;
	  input strength @@;
	  output;
  end; end;
  lines;
  1   10 12   13 17   21 30   18 16   17 21
  2   15 19   14 12   30 38   15 11   14 12
  3   10  8   12  9   10  5   14 15   19 11
;
* Data by observation;
data weldstrength;
  input gage time trtmt strength;
  lines;
          1    1   11      10
          1    1   11      12
          1    2   12      13
          1    2   12      17
          1    3   13      21
          1    3   13      30
          1    4   14      18
          1    4   14      16
          1    5   15      17
          1    5   15      21
          2    1   21      15
          2    1   21      19
          2    2   22      14
          2    2   22      12
          2    3   23      30
          2    3   23      38
          2    4   24      15
          2    4   24      11
          2    5   25      14
          2    5   25      12
          3    1   31      10
          3    1   31       8
          3    2   32      12
          3    2   32       9
          3    3   33      10
          3    3   33       5
          3    4   34      14
          3    4   34      15
          3    5   35      19
          3    5   35      11
;
run;
