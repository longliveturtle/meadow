* catalyst.sas, catalyst experiment, Table 5.18, p134;
;
data catalyst;
*  treatment codes:  AX=11,  AY=12,  AZ=13;
*                    BX=21,  BY=22,  BZ=23;
*                    CX=31,  CY=32,  CZ=33;
*                    DX=41,  DY=42,  DZ=43;
  input order trtmt yield;
  lines;
           1   32     9
           2   13     5
           3   41    12
           4   12     7
           5   31    13
           6   43     7
           7   11     4
           8   33    13
           9   22    13
          10   33    13
          11   23     7
          12   41    12
          13   21     4
          14   31    15
          15   42    12
          16   23     9
          17   21     6
          18   42    14
          19   12    11
          20   43     9
          21   22    15
          22   11     6
          23   32    15
          24   13     9
;
run;
