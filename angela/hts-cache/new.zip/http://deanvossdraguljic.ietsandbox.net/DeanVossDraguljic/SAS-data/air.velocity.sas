* air.velocity.sas, air velocity experiment, Table 6.11, p175;
;
* Data as arranged in Table 6.11;
data air;
  do RibHt=1 to 3;
    do ReyNo=1 to 6;
      input velocity @@;
      output;
  end; end;
  lines;
  -24 -23   1   8  29  23 
   33  28  45  57  74  80 
   37  79  79  95 101 111 
;
* Data by observation;
data air;
  input ReyNo RibHt velocity;
  lines;
          1     1      -24
          1     2       33
          1     3       37
          2     1      -23
          2     2       28
          2     3       79
          3     1        1
          3     2       45
          3     3       79
          4     1        8
          4     2       57
          4     3       95
          5     1       29
          5     2       74
          5     3      101
          6     1       23
          6     2       80
          6     3      111
;
run;
