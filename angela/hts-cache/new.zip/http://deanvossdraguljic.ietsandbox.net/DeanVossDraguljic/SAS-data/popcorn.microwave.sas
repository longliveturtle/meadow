* popcorn.microwave.sas, popcorn-microwave experiment, Table 7.2, p217;
;
* Data as arranged in Table 7.2;
data popmic;
  input brand power @@;
  do time=1 to 3;
    do rep=1 to 2; drop rep;
	  input y @@;
	  output;
  end; end;
  lines;
  1 1  73.8 65.5  70.3 91.0  72.7 81.9
  1 2  70.8 75.3  78.7 88.7  74.1 72.1
  2 1  73.7 65.8  93.4 76.3  45.3 47.6
  2 2  79.3 86.5  92.2 84.7  66.3 45.7
  3 1  62.5 65.0  50.1 81.5  51.4 67.7
  3 2  82.1 74.5  71.5 80.0  64.0 77.0
;
* Data by observation;
data popmic;
  input brand power time  y;
  lines;
          1     1     1  73.8
          1     1     1  65.5
          1     1     2  70.3
          1     1     2  91.0
          1     1     3  72.7
          1     1     3  81.9
          1     2     1  70.8
          1     2     1  75.3
          1     2     2  78.7
          1     2     2  88.7
          1     2     3  74.1
          1     2     3  72.1
          2     1     1  73.7
          2     1     1  65.8
          2     1     2  93.4
          2     1     2  76.3
          2     1     3  45.3
          2     1     3  47.6
          2     2     1  79.3
          2     2     1  86.5
          2     2     2  92.2
          2     2     2  84.7
          2     2     3  66.3
          2     2     3  45.7
          3     1     1  62.5
          3     1     1  65.0
          3     1     2  50.1
          3     1     2  81.5
          3     1     3  51.4
          3     1     3  67.7
          3     2     1  82.1
          3     2     1  74.5
          3     2     2  71.5
          3     2     2  80.0
          3     2     3  64.0
          3     2     3  77.0
;
run;
