* machine.head.sas, machine head experiment, Table 18.3, p684;
;
* Data as arranged in Table 18.3;
data machine;
  input machine @@;
  do head=1 to 4;
    do rep=1 to 4; drop rep;
	  input y @@;
	  output;
  end; end;
  lines;
  1   6  2  0  8   13  3  9  8    1 10  0  6    7  4  7  9
  2  10  9  7 12    2  1  1 10    4  1  7  9    0  3  4  1
  3   0  0  5  5   10 11  6  7    8  5  0  7    7  2  5  4
  4  11  0  6  4    5 10  8  3    1  8  9  4    0  8  6  5
  5   1  4  7  9    6  7  0  3    3  0  2  2    3  7  4  0
;
* Data by observation;
data machine;
 input machine head   y;
 lines;
          1     1     6
          1     1     2
          1     1     0
          1     1     8
          1     2    13
          1     2     3
          1     2     9
          1     2     8
          1     3     1
          1     3    10
          1     3     0
          1     3     6
          1     4     7
          1     4     4
          1     4     7
          1     4     9
          2     1    10
          2     1     9
          2     1     7
          2     1    12
          2     2     2
          2     2     1
          2     2     1
          2     2    10
          2     3     4
          2     3     1
          2     3     7
          2     3     9
          2     4     0
          2     4     3
          2     4     4
          2     4     1
          3     1     0
          3     1     0
          3     1     5
          3     1     5
          3     2    10
          3     2    11
          3     2     6
          3     2     7
          3     3     8
          3     3     5
          3     3     0
          3     3     7
          3     4     7
          3     4     2
          3     4     5
          3     4     4
          4     1    11
          4     1     0
          4     1     6
          4     1     4
          4     2     5
          4     2    10
          4     2     8
          4     2     3
          4     3     1
          4     3     8
          4     3     9
          4     3     4
          4     4     0
          4     4     8
          4     4     6
          4     4     5
          5     1     1
          5     1     4
          5     1     7
          5     1     9
          5     2     6
          5     2     7
          5     2     0
          5     2     3
          5     3     3
          5     3     0
          5     3     2
          5     3     2
          5     4     3
          5     4     7
          5     4     4
          5     4     0
;
run;