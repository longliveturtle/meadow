* air.freshener.sas, air freshener experiment, Table 12.17, p427;
;
* Data as arranged in Table 12.17, p427;
data air;
  input week @@;
  do store=1 to 8;
    input trtmt sales @@;
    output;
  end;
  lines;
  1  2 31  1 23  3 12  4  3  1 10  3 30  2 23  4 14
  2  1 19  4 16  2 14  3  4  2 21  4 25  3 17  1 14
  3  4 15  3 30  1 12  2  6  3 12  1 47  4  5  2  3
  4  3 16  2 27  4  5  1 11  4 12  2 38  1 13  3  6
; 
* Data by observation;
data air;
  input week store trtmt sales;
  lines;
          1    1     2     31
          1    2     1     23
          1    3     3     12
          1    4     4      3
          1    5     1     10
          1    6     3     30
          1    7     2     23
          1    8     4     14
          2    1     1     19
          2    2     4     16
          2    3     2     14
          2    4     3      4
          2    5     2     21
          2    6     4     25
          2    7     3     17
          2    8     1     14
          3    1     4     15
          3    2     3     30
          3    3     1     12
          3    4     2      6
          3    5     3     12
          3    6     1     47
          3    7     4      5
          3    8     2      3
          4    1     3     16
          4    2     2     27
          4    3     4      5
          4    4     1     11
          4    5     4     12
          4    6     2     38
          4    7     1     13
          4    8     3      6 
;
run;
