* battery.sas, battery experiment, Table 2.8, p27;
;
data battery;
  *  LPUC is life per unit cost (min/$);
  input TypeBat Life UCost LPUC Order;
  lines;
           1     602 0.985  611    1
           2     863 0.935  923    2
           1     529 0.985  537    3
           4     235 0.495  476    4
           1     534 0.985  542    5
           1     585 0.985  593    6
           2     743 0.935  794    7
           3     232 0.520  445    8
           4     282 0.495  569    9
           2     773 0.935  827   10
           2     840 0.935  898   11
           3     255 0.520  490   12
           4     238 0.495  480   13
           3     200 0.520  384   14
           4     228 0.495  460   15
           3     215 0.520  413   16
;
run;


