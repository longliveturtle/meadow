*  heart.lung.pump.sas, heart-lung pump experiment, Table 3.2, p38;
;
data heart;
  input order RPM y;
  lines;
   1 5 3.540
   2 1 1.158
   3 1 1.128
   4 2 1.686
   5 5 3.480
   6 5 3.510
   7 3 2.328
   8 3 2.340
   9 3 2.298
  10 4 2.982
  11 3 2.328
  12 1 1.140
  13 4 2.868
  14 5 3.504
  15 3 2.340
  16 2 1.740
  17 1 1.122
  18 1 1.128
  19 5 3.612
  20 2 1.740
;
run;