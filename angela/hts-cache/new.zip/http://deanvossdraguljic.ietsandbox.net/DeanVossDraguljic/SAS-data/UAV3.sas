* UAV3.sas, UAV switch experiment: Table 19.18 (p735), Table 19.19 (p736);
;
* Data as arranged in Table 19.18;
DATA UAV3;
  do A=1 to 2;
    do B=1 to 2;
	  do W=1 to 8;
	    input Time @@;
		output;
  end; end; end;
  lines;
   6  5  5  5  5  7  5  6
  16 22 16 20 12 18 16 14
   7  6  5  6  5  6  4  4
   6  7  6  8  6  6  7  6
;
* Data by observation, as in Table 19.19;
DATA UAV3;
  INPUT A W B TIME;
  LINES;
        1 1 1   6
        1 1 2  16
        1 2 1   5
        1 2 2  22
        1 3 1   5
        1 3 2  16
        1 4 1   5
        1 4 2  20
        1 5 1   5
        1 5 2  12
        1 6 1   7
        1 6 2  18
        1 7 1   5
        1 7 2  16
        1 8 1   6
        1 8 2  14
        2 1 1   7
        2 1 2   6
        2 2 1   6
        2 2 2   7
        2 3 1   5
        2 3 2   6
        2 4 1   6
        2 4 2   8
        2 5 1   5
        2 5 2   6
        2 6 1   6
        2 6 2   6
        2 7 1   4
        2 7 2   7
        2 8 1   4
        2 8 2   6
;
run;
