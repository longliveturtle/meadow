* ammunition.sas, ammunition experiment, Table 17.5, p633;
;
* Data as arranged in Table 17.5, p633;
data ammo;
  do PLot=1 to 4;
    do rep=1 to 2; drop rep;
      do CLot=1 to 4;
        input velocity @@;
        output;
  end; end; end;       
  lines;
  63 56 69 78
  78 58 63 79
  71 60 64 65
  70 65 68 77
  72 58 69 63
  55 55 71 72
  70 60 66 73
  64 71 68 79
;
* Data by observation;
data ammo;
  input PLot CLot velocity;
  lines;
          1    1     63
          1    1     78
          1    2     56
          1    2     58
          1    3     69
          1    3     63
          1    4     78
          1    4     79
          2    1     71
          2    1     70
          2    2     60
          2    2     65
          2    3     64
          2    3     68
          2    4     65
          2    4     77
          3    1     72
          3    1     55
          3    2     58
          3    2     55
          3    3     69
          3    3     71
          3    4     63
          3    4     72
          4    1     70
          4    1     64
          4    2     60
          4    2     71
          4    3     66
          4    3     68
          4    4     73
          4    4     79
;
run;
