* meat.cooking.sas, meat cooking experiment, Table 3.14, p68;
;
* Data as arranged in Table 3.14;
data meat;
  do rep=1 to 5;
    do Method=1 to 2;
      do Fat=1 to 3;
        input WtLoss @@;
        output;
  end; end; end;
  lines;
  81 85 71   84 83 78
  88 80 77   84 88 75
  85 82 72   82 85 78
  84 80 80   81 86 79
  84 82 80   86 88 82
;
* Data by observation, by column from Table 3.14;
data meat;
  input Method Fat WtLoss;
  lines;
           1    1    81
           1    1    88
           1    1    85
           1    1    84
           1    1    84
           1    2    85
           1    2    80
           1    2    82
           1    2    80
           1    2    82
           1    3    71
           1    3    77
           1    3    72
           1    3    80
           1    3    80
           2    1    84
           2    1    84
           2    1    82
           2    1    81
           2    1    86
           2    2    83
           2    2    88
           2    2    85
           2    2    86
           2    2    88
           2    3    78
           2    3    75
           2    3    78
           2    3    79
           2    3    82
;
run;
