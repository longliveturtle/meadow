* survival.sas, survival experiment, Table 6.25, p198;
;
* Data as arranged in Table 6.25;
data survival;
  input poison @@;
  do rep=1 to 4; drop rep;
    do trtmt=1 to 4;
	  input time @@;
	  output;
  end; end;
  lines;
  1 0.31 0.82 0.43 0.45
    0.45 1.10 0.45 0.71
    0.46 0.88 0.63 0.66
    0.43 0.72 0.76 0.62
  2 0.36 0.92 0.44 0.56
    0.29 0.61 0.35 1.02
    0.40 0.49 0.31 0.71
    0.23 1.24 0.40 0.38
  3 0.22 0.30 0.23 0.30
    0.21 0.37 0.25 0.36
    0.18 0.38 0.24 0.31
    0.23 0.29 0.22 0.33
;
proc sort; by poison trtmt;
data survival; set survival;
put '     ' poison '    ' trtmt time 6.2;
run;

* Data by observation;
data poison;
  input poison trtmt time;
  lines;
           1     1   0.31
           1     1   0.45
           1     1   0.46
           1     1   0.43
           1     2   0.82
           1     2   1.10
           1     2   0.88
           1     2   0.72
           1     3   0.43
           1     3   0.45
           1     3   0.63
           1     3   0.76
           1     4   0.45
           1     4   0.71
           1     4   0.66
           1     4   0.62
           2     1   0.36
           2     1   0.29
           2     1   0.40
           2     1   0.23
           2     2   0.92
           2     2   0.61
           2     2   0.49
           2     2   1.24
           2     3   0.44
           2     3   0.35
           2     3   0.31
           2     3   0.40
           2     4   0.56
           2     4   1.02
           2     4   0.71
           2     4   0.38
           3     1   0.22
           3     1   0.21
           3     1   0.18
           3     1   0.23
           3     2   0.30
           3     2   0.37
           3     2   0.38
           3     2   0.29
           3     3   0.23
           3     3   0.25
           3     3   0.24
           3     3   0.22
           3     4   0.30
           3     4   0.36
           3     4   0.31
           3     4   0.33
;
run;
