* lithium.sas, lithium bioavailability experiment, Table 11.31, p394;
;
* Data as arranged in Table 11.31;
data lithium;
  do EU=1 to 2; drop EU;
    do subject=1 to 6;
	  input trtmt y @@;
	  output;
  end; end;
  do EU=1 to 2;
    do subject=7 to 12;
	  input trtmt y @@;
	  output;
  end; end;
  lines;
  1 .467  4 .450  3 .200  2 .520  4 .600  4 .467 
  2 .440  3 .156  1 .533  3 .222  1 .467  2 .520 
  2 .600  2 .640  3 .156  1 .533  1 .433  3 .156 
  1 .467  4 .400  4 .467  4 .433  3 .267  2 .520 
;
* Data by observation;
data lithium;
  input subject trtmt   y;
  lines;
           1      1   0.467
           1      2   0.440
           2      4   0.450
           2      3   0.156
           3      3   0.200
           3      1   0.533
           4      2   0.520
           4      3   0.222
           5      4   0.600
           5      1   0.467
           6      4   0.467
           6      2   0.520
           7      2   0.600
           7      1   0.467
           8      2   0.640
           8      4   0.400
           9      3   0.156
           9      4   0.467
          10      1   0.533
          10      4   0.433
          11      1   0.433
          11      3   0.267
          12      3   0.156
          12      2   0.520
;
run;
