* ink.sas, ink experiment, Table 6.24, p197;
;
data ink;
  input cloth detergnt order score;
  lines;
          3      2       1     1
          1      2       2     6
          3      2       3     1
          1      2       4     5
          2      1       5    11
          1      1       6     9
          2      1       7     9
          2      2       8     8
          2      2       9     6
          3      1      10     3
          3      1      11     4
          1      1      12     8
;
run;