* respiratory.exchange.sas, respiratory exchange ratio experiment, Table 10.18, p336;
;
* Data as arranged in Table 10.18;
data resp;
  input subject @@;
  do protocol=1 to 3;
    input ratio @@;
	output;
  end;
  lines;
  1 0.79 0.80 0.83
  2 0.84 0.84 0.81
  3 0.84 0.93 0.88
  4 0.83 0.85 0.79
  5 0.84 0.78 0.88
  6 0.83 0.75 0.86
  7 0.77 0.76 0.71
  8 0.83 0.85 0.78
  9 0.81 0.77 0.72
;
* Data by observation;
data resp;
  input subject protocol ratio;
  lines;
           1        1     0.79
           1        2     0.80
           1        3     0.83
           2        1     0.84
           2        2     0.84
           2        3     0.81
           3        1     0.84
           3        2     0.93
           3        3     0.88
           4        1     0.83
           4        2     0.85
           4        3     0.79
           5        1     0.84
           5        2     0.78
           5        3     0.88
           6        1     0.83
           6        2     0.75
           6        3     0.86
           7        1     0.77
           7        2     0.76
           7        3     0.71
           8        1     0.83
           8        2     0.85
           8        3     0.78
           9        1     0.81
           9        2     0.77
           9        3     0.72
;
run;
