* decon.alpha.sas, decontamination (alpha-particle) experiment, Table 13.13, p452;
;
* Data as arranged in Table 13.13;
data alpha1 (keep=block trtmt A B C D) alpha2 (keep=block count);
  do block=1 to 4;
    do col=1 to 8; 
      input trtmt $ @@;
      A=substr(trtmt,1,1);
      B=substr(trtmt,2,1);        
      C=substr(trtmt,3,1);
      D=substr(trtmt,4,1);
      output alpha1;
    end;
    do col=1 to 8;
      input count @@;
      output alpha2;
    end;
  end;
  lines;
  1010 1111 0110 0000 1100 0101 0011 1001
   183  350  188  881  225  298 1039  466 
  0010 0001 0111 1000 1101 0100 1110 1011
   650 1180  238  191  420  289  135  781 
  0101 1001 1100 0000 1010 1111 0110 0011
   273  890  370  834  193  389  163 1146 
  0001 1110 1000 0100 0111 1011 0010 1101
  1193  156  257  178  254  775  494  429 
;
data alpha; merge alpha1 alpha2;
;
* Data by observation;
data alpha;
  input block trtmt $ A B C D count;
  lines;
          1    1010   1 0 1 0  183
          1    1111   1 1 1 1  350
          1    0110   0 1 1 0  188
          1    0000   0 0 0 0  881
          1    1100   1 1 0 0  225
          1    0101   0 1 0 1  298
          1    0011   0 0 1 1 1039
          1    1001   1 0 0 1  466
          2    0010   0 0 1 0  650
          2    0001   0 0 0 1 1180
          2    0111   0 1 1 1  238
          2    1000   1 0 0 0  191
          2    1101   1 1 0 1  420
          2    0100   0 1 0 0  289
          2    1110   1 1 1 0  135
          2    1011   1 0 1 1  781
          3    0101   0 1 0 1  273
          3    1001   1 0 0 1  890
          3    1100   1 1 0 0  370
          3    0000   0 0 0 0  834
          3    1010   1 0 1 0  193
          3    1111   1 1 1 1  389
          3    0110   0 1 1 0  163
          3    0011   0 0 1 1 1146
          4    0001   0 0 0 1 1193
          4    1110   1 1 1 0  156
          4    1000   1 0 0 0  257
          4    0100   0 1 0 0  178
          4    0111   0 1 1 1  254
          4    1011   1 0 1 1  775
          4    0010   0 0 1 0  494
          4    1101   1 1 0 1  429
; 
run;
