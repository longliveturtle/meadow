* decon.beta2.sas, decontamination (beta-particle) experiment, Table 13.49, p549;
;
* Data as arranged in Table 13.49;
data beta1 (keep=trtmt A B C D) beta2 (keep=count);
  do col=1 to 8; 
    input trtmt $ @@;
    A=substr(trtmt,1,1);
    B=substr(trtmt,2,1);        
    C=substr(trtmt,3,1);
    D=substr(trtmt,4,1);
    output beta1;
  end;
  do col=1 to 8;
    input count @@;
    output beta2;
  end;
  lines;
  1010 1111 0110 0000 1100 0101 0011 1001
   716  686  498 1437  527  579 1433  906 
;
data beta; merge beta1 beta2;
;
* Data by observation;
data beta;
  input trtmt $ A B C D count;
  lines;
         1010   1 0 1 0  716
         1111   1 1 1 1  686
         0110   0 1 1 0  498
         0000   0 0 0 0 1437
         1100   1 1 0 0  527
         0101   0 1 0 1  579
         0011   0 0 1 1 1433
         1001   1 0 0 1  906
; 
run;
