* rust.sas, rust experiment, Table 11.28, p391;
;
* Data as arranged in Table 11.28;
data rust;
  input temp @@;
  do block=1 to 10;
    input pct @@;
	if pct ne . then output;
  end;
  lines;
  50  12 19  .  .  . 20 10 21 19  . 
  55  18  . 33  . 19  . 18  . 18 24
  60  24 36  . 35 39 22  .  .  . 28
  65   .  . 39 45  . 43 34 42  . 31
  70   . 45 52 55 48  .  . 50 43  . 
;
* Data by observation;
data rust;
  input block temp pct;
  lines;
          1    50   12
          1    55   18
          1    60   24
          2    50   19
          2    60   36
          2    70   45
          3    55   33
          3    65   39
          3    70   52
          4    60   35
          4    65   45
          4    70   55
          5    55   19
          5    60   39
          5    70   48
          6    50   20
          6    60   22
          6    65   43
          7    50   10
          7    55   18
          7    65   34
          8    50   21
          8    65   42
          8    70   50
          9    50   19
          9    55   18
          9    70   43
         10    55   24
         10    60   28
         10    65   31
;
run;
