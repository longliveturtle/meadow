* temperature.sas, temperature experiment, Table 17.10, p650;
;
* Data as arranged in Table 17.10, p650;
data tempr;
  do subj=1 to 4;
    do trtmt=11,12,21,22,31,32; 
      TC=put(trtmt,2.); * Convert to character variable;
      drop trtmt;
      therm=substr(TC,1,1);
      site=substr(TC,2,1);
      input time @@;
      output;
  end; end;
  lines;
  62.16  61.53 154.42 310.46  95.98 225.65
  65.63  63.70 132.30 284.64  98.50 241.63
  63.12  61.34 105.52 315.61 110.05 364.07
  61.51  61.54  94.88 294.16 107.93 304.58
;
* Data by observation, as in Table 17.13, p654;
data tempr;
  input therm site subj  time;
  lines;
          1     1    1   62.16
          1     2    1   61.53
          2     1    1  154.42
          2     2    1  310.46
          3     1    1   95.98
          3     2    1  225.65
          1     1    2   65.63
          1     2    2   63.70
          2     1    2  132.30
          2     2    2  284.64
          3     1    2   98.50
          3     2    2  241.63
          1     1    3   63.12
          1     2    3   61.34
          2     1    3  105.52
          2     2    3  315.61
          3     1    3  110.05
          3     2    3  364.07
          1     1    4   61.51
          1     2    4   61.54
          2     1    4   94.88
          2     2    4  294.16
          3     1    4  107.93
          3     2    4  304.58
;
run;
