* detergent.sas, detergent experiment, Table 11.8 (p361), Table 11.18 (p378);
;
* Data as arranged in Table 11.8;
data detergnt;
  input block trtmt1 trtmt2 trtmt3 y1 y2 y3;
  trtmt=trtmt1; y=y1; output;
  trtmt=trtmt2; y=y2; output;
  trtmt=trtmt3; y=y3; output;   
  lines;
   1  3 8 4  13 20  7
   2  4 9 2   6 29 17
   3  3 6 9  15 23 31
   4  9 5 1  31 26 20
   5  2 7 6  16 21 23
   6  6 5 4  23 26  6
   7  9 8 7  28 19 21
   8  7 1 4  20 20  7
   9  6 8 1  24 19 20
  10  5 8 2  26 19 17
  11  5 3 7  24 14 21
  12  3 2 1  11 17 19
;
* Data by observation, as in Table 11.18, p378;
DATA ONE;
  INPUT BLOCK TRTMT  Y;
  LINES;
           1    3    13
           1    8    20
           1    4     7
           2    4     6
           2    9    29
           2    2    17
           3    3    15
           3    6    23
           3    9    31
           4    9    31
           4    5    26
           4    1    20
           5    2    16
           5    7    21
           5    6    23
           6    6    23
           6    5    26
           6    4     6
           7    9    28
           7    8    19
           7    7    21
           8    7    20
           8    1    20
           8    4     7
           9    6    24
           9    8    19
           9    1    20
          10    5    26
          10    8    19
          10    2    17
          11    5    24
          11    3    14
          11    7    21
          12    3    11
          12    2    17
          12    1    19
;
run;
