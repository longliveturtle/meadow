* clean.wool.sas, clean wool experiment, Table 17.1, p617;
;
* Data as arranged in Table 17.1;
data wool;
  do rep=1 to 4;
    do bail=1 to 7;
      input content @@;
      output;
  end; end;
  lines;
  52.33 56.99 54.64 54.90 59.89 57.76 60.27
  56.26 58.69 57.48 60.08 57.76 59.68 60.30
  62.86 58.20 59.29 58.72 60.26 59.58 61.09
  50.46 57.35 57.51 55.61 57.53 58.08 61.45
;
* Data by observation, by column of Table 17.1, p617;
DATA WOOL;
  INPUT BALE CONTENT;
  LINES;
          1   52.33
          1   56.26
          1   62.86
          1   50.46
          2   56.99
          2   58.69
          2   58.20
          2   57.35
          3   54.64
          3   57.48
          3   59.29
          3   57.51
          4   54.90
          4   60.08
          4   58.72
          4   55.61
          5   59.89
          5   57.76
          5   60.26
          5   57.53
          6   57.76
          6   59.68
          6   59.58
          6   58.08
          7   60.27
          7   60.30
          7   61.09
          7   61.45
;
run;
