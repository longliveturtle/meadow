* systolic.blood.pressure.sas, systolic blood pressure experiment, Table 8.14, p282;
;
data SysBP;
  input jogtime SBP order;
  lines;
          10    120   1
          10    118   9
          20    125   2
          20    126   4
          20    123   8
          25    127  10
          30    128   3
          30    131   7
          40    137   5
          50    143   6
;
run;
