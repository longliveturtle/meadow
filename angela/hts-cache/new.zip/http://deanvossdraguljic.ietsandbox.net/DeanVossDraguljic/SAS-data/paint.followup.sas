* paint.followup.sas, paint followup experiment, Table 16.23, p609;
;
* Data as arranged in Table 16.23;
data paint2;
  input zA zB zC zD y1 y2;
  y=y1; output;
  y=y2; output;
  lines;
  -1.5  0 -2  0  1.71  1.61
   0.5  0 -2  0  0.91  1.30
  -1.5 -2  0  0  1.71  1.60
   0.5 -2  0  0  1.15  1.29
  -1.5  0  0 -2  1.33  1.06
   0.5  0  0 -2  1.74  1.98
  -1.5 -2 -2 -2  0.64  0.78
   0.5 -2 -2 -2  1.51  1.18
;
* Data by observation;
data paint2;
  input zA zB zC zD    y;
  lines;
      -1.5  0 -2  0  1.71
      -1.5  0 -2  0  1.61
       0.5  0 -2  0  0.91
       0.5  0 -2  0  1.30
      -1.5 -2  0  0  1.71
      -1.5 -2  0  0  1.60
       0.5 -2  0  0  1.15
       0.5 -2  0  0  1.29
      -1.5  0  0 -2  1.33
      -1.5  0  0 -2  1.06
       0.5  0  0 -2  1.74
       0.5  0  0 -2  1.98
      -1.5 -2 -2 -2  0.64
      -1.5 -2 -2 -2  0.78
       0.5 -2 -2 -2  1.51
       0.5 -2 -2 -2  1.18 
;
run;
