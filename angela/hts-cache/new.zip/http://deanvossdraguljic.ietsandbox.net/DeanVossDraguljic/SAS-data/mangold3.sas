* mangold3.sas, mangold experiment, Table 15.50, p550;
;
data mangold3;
  input trtmt $ A B C D E   y;
  lines;
        00101   0 0 1 0 1  896
        11001   1 1 0 0 1 1284
        01011   0 1 0 1 1  996
        01110   0 1 1 1 0  860
        10010   1 0 0 1 0 1184
        11100   1 1 1 0 0  984
        00000   0 0 0 0 0  740
        10111   1 0 1 1 1 1468
;
run;
