* UAV3ADT.sas, UAV switch experiment, Table 19.37, p763;
;
* Data as arranged in Table 19.37;
DATA UAV3ADT;
  do A=1 to 2;
    do B=1 to 2;
	  do W=1 to 8;
	    input Time @@;
		output;
  end; end; end;
  lines;
   5  6  4  6  5  5  5  6
  10 10  6  8  6  6  6  6
   6  5  4  5  5  4  6  6
   5  6  4  5  5  4  6  5
;
* Data by observation;
DATA UAV3ADT;
  INPUT A B W TIME;
  LINES;
        1 1 1   5
        1 1 2   6
        1 1 3   4
        1 1 4   6
        1 1 5   5
        1 1 6   5
        1 1 7   5
        1 1 8   6
        1 2 1  10
        1 2 2  10
        1 2 3   6
        1 2 4   8
        1 2 5   6
        1 2 6   6
        1 2 7   6
        1 2 8   6
        2 1 1   6
        2 1 2   5
        2 1 3   4
        2 1 4   5
        2 1 5   5
        2 1 6   4
        2 1 7   6
        2 1 8   6
        2 2 1   5
        2 2 2   6
        2 2 3   4
        2 2 4   5
        2 2 5   5
        2 2 6   4
        2 2 7   6
        2 2 8   5
;
run;
