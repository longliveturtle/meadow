* zinc.plating.sas, zinc plating experiment, Table 9.8, p302;
;
* Data as arranged in Table 9.8;
data zinc;
  do vendor=1 to 3;
    input x y @@;
	output;
  end;
  lines;
  110 40   60 25   62 27
   75 38   75 32   90 24
   93 30   38 13   45 20
   97 47  140 35   59 13
;
* Data by observation, sorted by vendor;
data zinc;
  input vendor   x   y;
  lines;
           1   110  40
           1    75  38
           1    93  30
           1    97  47
           2    60  25
           2    75  32
           2    38  13
           2   140  35
           3    62  27
           3    90  24
           3    45  20
           3    59  13
;
run;
