* fabric.stain.sas, fabric stain experiment, Table 11.33, p396;
;
* Data as arranged in Table 11.33;
data fabric;
  input block @@;
  do col=2 to 7;
    input trtmt y @@;
    output;
  end;
  lines;
  1  1 35  6 35  8 20  10 80  15 65  17 10 
  2  2 30  4 25  9 10  11 75  13 60  18 15 
  3  3 30  5 30  7 30  12 75  14 60  16 15 
  4  1 20  5 30  9 15  10 80  14 65  18 20 
  5  2 20  6 15  7 10  11 80  15 65  16 15 
  6  3 20  4 15  8 20  12 70  13 50  17 15 
;
* Data by observation;
data fabric;
  input block trtmt y;
  lines;
          1     1   35
          1     6   35
          1     8   20
          1    10   80
          1    15   65
          1    17   10
          2     2   30
          2     4   25
          2     9   10
          2    11   75
          2    13   60
          2    18   15
          3     3   30
          3     5   30
          3     7   30
          3    12   75
          3    14   60
          3    16   15
          4     1   20
          4     5   30
          4     9   15
          4    10   80
          4    14   65
          4    18   20
          5     2   20
          5     6   15
          5     7   10
          5    11   80
          5    15   65
          5    16   15
          6     3   20
          6     4   15
          6     8   20
          6    12   70
          6    13   50
          6    17   15
;
run;
