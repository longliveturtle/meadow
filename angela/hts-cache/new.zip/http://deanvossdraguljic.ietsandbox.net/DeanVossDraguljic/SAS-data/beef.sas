* beef.sas, beef experiment, Exercise 11.11, Table 11.30, p393;
;
* Data as arranged in Table 11.30;
data beef;
  input block @@; 
  do trtmt=1 to 6; 
    input y @@;
    if y ne . then output;
  end; 
  lines;
   1   7 17  .  .  .  .
   2   .  . 26 25  .  .
   3   .  .  .  . 33 29
   4  17  . 27  .  .  .
   5   . 23  .  . 27  .
   6   .  .  . 29  . 30
   7  10  .  . 25  .  .
   8   . 26  .  .  . 37
   9   .  . 24  . 26  .
  10  25  .  .  . 40  .
  11   . 25  . 34  .  .
  12   .  . 34  .  . 32
  13  11  .  .  .  . 27
  14   . 24 21  .  .  .
  15   .  .  . 26 32  .
;
* Data by observation;
data beef;
  input block trtmt  y;
  lines;
           1    1    7
           1    2   17
           2    3   26
           2    4   25
           3    5   33
           3    6   29
           4    1   17
           4    3   27
           5    2   23
           5    5   27
           6    4   29
           6    6   30
           7    1   10
           7    4   25
           8    2   26
           8    6   37
           9    3   24
           9    5   26
          10    1   25
          10    5   40
          11    2   25
          11    4   34
          12    3   34
          12    6   32
          13    1   11
          13    6   27
          14    2   24
          14    3   21
          15    4   26
          15    5   32
;
run;
