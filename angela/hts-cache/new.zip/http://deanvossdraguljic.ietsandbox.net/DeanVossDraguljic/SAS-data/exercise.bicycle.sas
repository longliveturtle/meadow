* exercise.bicycle.sas, exercise bicycle experiment, Table 12.6 (p405), Table 12.10 (p417);
;
* Data as arranged in Table 12.6;
data bike;
  input day trtmt1 y1 trtmt2 y2 trtmt3 y3;
  subject=1; trtmt=trtmt1; y=y1; output;
  subject=2; trtmt=trtmt2; y=y2; output;
  subject=3; trtmt=trtmt3; y=y3; output;
  keep day subject trtmt y;
  lines;
  1  112 45  212 25  221 18
  2  222 27  211 20  212 32
  3  212 40  222 23  112 28
  4  221 17  112 32  122 24
  5  211 30  111 36  222 20
  6  122 29  221 13  121 20
  7  111 34  121 18  211 25
  8  121 21  122 22  111 34
;
* Data by observtion, as in Table 12.10, p417;
DATA BIKE;
  INPUT DAY SUBJECT PULSE DURAT$ SPEED$ PEDAL$;
  TRTMT = trim(DURAT)||trim(SPEED)||trim(PEDAL);
  LINES;
         1     1      45    1      1      2
         1     2      25    2      1      2
         1     3      18    2      2      1
         2     1      27    2      2      2
         2     2      20    2      1      1
         2     3      32    2      1      2
         3     1      40    2      1      2
         3     2      23    2      2      2
         3     3      28    1      1      2
         4     1      17    2      2      1
         4     2      32    1      1      2
         4     3      24    1      2      2
         5     1      30    2      1      1
         5     2      36    1      1      1
         5     3      20    2      2      2
         6     1      29    1      2      2
         6     2      13    2      2      1
         6     3      20    1      2      1
         7     1      34    1      1      1
         7     2      18    1      2      1
         7     3      25    2      1      1
         8     1      21    1      2      1
         8     2      22    1      2      2
         8     3      34    1      1      1
;
run;
