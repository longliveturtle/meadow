* dye.sas, Table 14.16, p487;
;
* Input the data;
DATA DYE;
  INPUT BLK A B C Y;
  LINES;
  1  0 0 0   74
  1  0 2 1  130
  1  0 1 2   56
  1  1 1 0  110
  1  1 0 1  166
  1  1 2 2  227
  1  2 2 0  195
  1  2 1 1  146
  1  2 0 2   90
  2  0 2 0   69
  2  0 1 1   46
  2  0 0 2   71
  2  1 0 0  211
  2  1 2 1  220
  2  1 1 2  216
  2  2 1 0  147
  2  2 0 1   47
  2  2 2 2  164
  3  0 1 0   13
  3  0 0 1  112
  3  0 2 2  125
  3  1 2 0  199
  3  1 1 1  218
  3  1 0 2  201
  3  2 0 0   74
  3  2 2 1  198
  3  2 1 2  102
  4  0 0 0   85
  4  0 1 1   52
  4  0 2 2   70
  4  1 2 0  164
  4  1 0 1  288
  4  1 1 2  239
  4  2 1 0  104
  4  2 2 1  165
  4  2 0 2   60
  5  0 1 0   12
  5  0 2 1  107
  5  0 0 2   75
  5  1 0 0  184
  5  1 1 1  204
  5  1 2 2  265
  5  2 2 0  183
  5  2 0 1   65
  5  2 1 2   70
  6  0 2 0  115
  6  0 0 1  148
  6  0 1 2   47
  6  1 1 0  145
  6  1 2 1  142
  6  1 0 2  216
  6  2 0 0   75
  6  2 1 1  124
  6  2 2 2  114
;
* Analysis of variance -- correct, with block effect;
PROC GLM;
  CLASS BLK A B C ;
  MODEL Y = BLK A B C A*B A*C B*C A*B*C ;
;
* Analysis of variance -- without block effect, for comparison;
PROC GLM;
  CLASS A B C;
  MODEL Y = A B C A*B A*C B*C A*B*C;
;
run;
