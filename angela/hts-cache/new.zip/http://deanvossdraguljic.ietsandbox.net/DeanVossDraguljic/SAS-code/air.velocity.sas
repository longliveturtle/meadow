* air.velocity.sas, air velocity experiment, Table 6.14, p184;
;
DATA AIR;
  INPUT Y A B Aln Aqd Bln Bqd Bcb Bqr Bqn;
  AlnBln = Aln*Bln;
  AlnBqd = Aln*Bqd;
  AlnBcb = Aln*Bcb;
  AlnBqr = Aln*Bqr;
  AqdBln = Aqd*Bln;
  AqdBqd = Aqd*Bqd;
  AqdBcb = Aqd*Bcb;
  LINES;
  -24      1   1      -1    1      -5   5  -5    1  -1
  -23      1   2      -1    1      -3  -1   7   -3   5
    1      1   3      -1    1      -1  -4   4    2 -10
    8      1   4      -1    1       1  -4  -4    2  10
   29      1   5      -1    1       3  -1  -7   -3  -5
   23      1   6      -1    1       5   5   5    1   1
   33      2   1       0   -2      -5   5  -5    1  -1
   28      2   2       0   -2      -3  -1   7   -3   5
   45      2   3       0   -2      -1  -4   4    2 -10
   57      2   4       0   -2       1  -4  -4    2  10
   74      2   5       0   -2       3  -1  -7   -3  -5
   80      2   6       0   -2       5   5   5    1   1
   37      3   1       1    1      -5   5  -5    1  -1
   79      3   2       1    1      -3  -1   7   -3   5
   79      3   3       1    1      -1  -4   4    2 -10
   95      3   4       1    1       1  -4  -4    2  10
  101      3   5       1    1       3  -1  -7   -3  -5
  111      3   6       1    1       5   5   5    1   1
;
PROC PRINT;
PROC GLM; * omit the class statement;
  MODEL Y = Aln Aqd Bln Bqd Bcb Bqr Bqn AlnBln AlnBqd
                  AlnBcb AlnBqr AqdBln AqdBqd AqdBcb;
;
run;