* detergent.sas, Table 11.18, p378;
;
DATA ONE;
  INPUT BLOCK TRTMT Y;
  LINES;
   1 3 13
   1 8 20
   1 4  7
   2 4  6
   2 9 29
   2 2 17
   3 3 15
   3 6 23
   3 9 31
   4 9 31
   4 5 26
   4 1 20
   5 2 16
   5 7 21
   5 6 23
   6 6 23
   6 5 26
   6 4  6
   7 9 28
   7 8 19
   7 7 21
   8 7 20
   8 1 20
   8 4  7
   9 6 24
   9 8 19
   9 1 20
  10 5 26
  10 8 19
  10 2 17
  11 5 24
  11 3 14
  11 7 21
  12 3 11
  12 2 17
  12 1 19
;
PROC SGPLOT;
  SCATTER X = TRTMT Y = Y / GROUP = BLOCK MARKERCHAR = BLOCK;
;
PROC GLM;
  CLASS BLOCK TRTMT;
  MODEL Y = BLOCK TRTMT;
  OUTPUT OUT = RESIDS PREDICTED = PREDY RESIDUALS = E;
  * contrast sums of squares for 8 orthogonal contrasts;
  CONTRAST 'I linear' TRTMT -3 -1 1 3 0 0 0 0 0;
  CONTRAST 'I quadratic' TRTMT 1 -1 -1 1 0 0 0 0 0;
  CONTRAST 'I cubic' TRTMT -1 3 -3 1 0 0 0 0 0;
  CONTRAST 'II linear' TRTMT 0 0 0 0 -3 -1 1 3 0;
  CONTRAST 'II quadratic' TRTMT 0 0 0 0 1 -1 -1 1 0;
  CONTRAST 'II cubic' TRTMT 0 0 0 0 -1 3 -3 1 0;
  CONTRAST 'I vs II' TRTMT 1 1 1 1 -1 -1 -1 -1 0;
  CONTRAST 'others vs control' TRTMT 1 1 1 1 1 1 1 1 -8;
  * estimation of treatment versus control contrasts via LSMEANS;
  LSMEANS TRTMT / PDIFF = CONTROL('9') CL ADJUST = DUNNETT;
  * estimation of treatment versus control contrast via ESTIMATE;
  ESTIMATE 'Det 9-1' TRTMT -1 0 0 0 0 0 0 0 1;
;
run;
