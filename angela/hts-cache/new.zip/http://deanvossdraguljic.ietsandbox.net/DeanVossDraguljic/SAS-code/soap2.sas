* soap2.sas, soap experiment, Table 3.9, p57;
;
DATA POWER;
  V = 3;
  DEL = 0.25;
  SIGMA2 = 0.007;
  ALPHA = 0.05;
  NU1 = V - 1;
  LHTPB = 1 - ALPHA;

DO R = 3 TO 6 BY 1;
  NU2 = V*(R - 1);
  PHI = (SQRT(R / (2*V*SIGMA2)))*DEL;
  FVALUE = FINV(LHTPB, NU1, NU2);
  NONCN = V*PHI**2;
  POWER = 1 - PROBF(FVALUE, NU1, NU2, NONCN);
  OUTPUT;
END;

PROC PRINT;
  VAR R POWER;

run;
