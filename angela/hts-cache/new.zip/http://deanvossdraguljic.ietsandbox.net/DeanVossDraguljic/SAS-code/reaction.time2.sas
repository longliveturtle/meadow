* reaction.time2.sas, reaction time experiment, SAS code from text pp182-3;
;
* Create data set for residual plots;
DATA RTIME;
  INPUT ORDER TRTMT A B Y;
  TC = PUT(10*A+B, 2.); * Create TC as character variable for plots;
  LINES;
  1 6 2 3 0.256
  2 6 2 3 0.281
  3 2 1 2 0.167
  4 6 2 3 0.258
  5 2 1 2 0.182
  6 5 2 2 0.283
  7 4 2 1 0.257
  8 5 2 2 0.235
  9 1 1 1 0.204
 10 1 1 1 0.170
 11 5 2 2 0.260
 12 2 1 2 0.187
 13 3 1 3 0.202
 14 4 2 1 0.279
;
* Fit factorial effects model and save info for residual plots;
PROC GLM NOPRINT;
  CLASS A B;
  MODEL Y = A B A*B;
  OUTPUT OUT=RTIME PREDICTED=YPRED RESIDUAL=Z;
PROC STANDARD STD=1.0; VAR Z;
PROC RANK NORMAL=BLOM; VAR Z; RANKS NSCORE;
;
* SAS code from text p182;
* Plot standardized residuals vs levels of A displaying levels of B;
PROC SGPLOT;
  SCATTER X = A Y = Z / GROUP = B;
;
* Interaction plot;
PROC SORT DATA = RTIME; BY A B;
PROC MEANS DATA = RTIME NOPRINT MEAN VAR; BY A B;
  VAR Y;
  OUTPUT OUT = RTIME2 MEAN = AV_Y VAR = VAR_Y;
PROC PRINT;
  VAR A B AV_Y VAR_Y;
PROC SGPLOT;
  SERIES X = A Y = AV_Y / GROUP = B;
;
* SAS code from text p183;
* Fit cell-means model and save info for residual plots;
PROC GLM DATA=RTIME;
  CLASS TC;
  MODEL Y = TC;
  OUTPUT OUT = RESIDS RESIDUAL = E;
;
* Plot standardized residuals vs treatment combinations;
PROC SGPLOT;
  SCATTER X = TC Y = Z; 
* Plot observations vs treatment combinations;
PROC SGPLOT;
  SCATTER X = TC Y = Y;
;
PROC SORT DATA = RESIDS; BY A;
PROC MEANS DATA = RESIDS NOPRINT VAR; BY A;
  VAR E;
  OUTPUT OUT = RTIME2 VAR = VAR_E;
PROC PRINT;
  VAR A VAR_E;
;
run;