* voltage.sas, voltage experiment, Table 18.7, p689;
;
DATA VLT;
  * Input setting station (B), regulator (C),
  * testing station (A), and voltage;
  INPUT B C A VOLTG;
  LINES;
   1 1 1 16.5
   1 1 2 16.5
   1 1 3 16.6
   1 1 4 16.6
   1 2 1 15.8
   1 2 2 16.7
   1 2 3 16.2
   1 2 4 16.3
   1 3 1 16.2
   1 3 2 16.5
   1 3 3 15.8
   1 3 4 16.1
   1 4 1 16.3
   1 4 2 16.5
   1 4 3 16.3
   1 4 4 16.6
   1 5 1 16.2
   1 5 2 16.1
   1 5 3 16.3
   1 5 4 16.5
   1 6 1 16.9
   1 6 2 17.0
   1 6 3 17.0
   1 6 4 17.0
   1 7 1 16.0
   1 7 2 16.2
   1 7 3 16.0
   1 7 4 16.0
   1 8 1 16.0
   1 8 2 16.0
   1 8 3 16.1
   1 8 4 16.0
   2 1 1 16.0
   2 1 2 16.1
   2 1 3 16.0
   2 1 4 16.1
   2 2 1 15.4
   2 2 2 16.4
   2 2 3 16.8
   2 2 4 16.7
   2 3 1 16.1
   2 3 2 16.4
   2 3 3 16.3
   2 3 4 16.3
   2 4 1 15.9
   2 4 2 16.1
   2 4 3 16.0
   2 4 4 16.0
   3 1 1 16.0
   3 1 2 16.0
   3 1 3 15.9
   3 1 4 16.3
   3 2 1 15.8
   3 2 2 16.0
   3 2 3 16.3
   3 2 4 16.0
   3 3 1 15.7
   3 3 2 16.2
   3 3 3 15.3
   3 3 4 15.8
   3 4 1 16.2
   3 4 2 16.4
   3 4 3 16.4
   3 4 4 16.6
   3 5 1 16.0
   3 5 2 16.1
   3 5 3 16.0
   3 5 4 15.9
   3 6 1 16.1
   3 6 2 16.1
   3 6 3 16.1
   3 6 4 16.1
   3 7 1 16.1
   3 7 2 16.0
   3 7 3 16.1
   3 7 4 16.0
   4 1 1 16.1
   4 1 2 16.0
   4 1 3 16.0
   4 1 4 16.2
   4 2 1 16.5
   4 2 2 16.1
   4 2 3 16.5
   4 2 4 16.7
   4 3 1 16.2
   4 3 2 17.0
   4 3 3 16.4
   4 3 4 16.7
   4 4 1 15.8
   4 4 2 16.1
   4 4 3 16.2
   4 4 4 16.2
   4 5 1 16.2
   4 5 2 16.1
   4 5 3 16.4
   4 5 4 16.2
   4 6 1 16.0
   4 6 2 16.2
   4 6 3 16.2
   4 6 4 16.1
   4 7 1 16.0
   4 7 2 16.0
   4 7 3 16.1
   4 7 4 16.0
   5 1 1 15.5
   5 1 2 15.6
   5 1 3 15.4
   5 1 4 15.8
   5 2 1 15.8
   5 2 2 16.2
   5 2 3 16.0
   5 2 4 16.2
   5 3 1 16.2
   5 3 2 15.4
   5 3 3 16.1
   5 3 4 16.3
   5 4 1 16.2
   5 4 2 16.2
   5 4 3 16.0
   5 4 4 16.1
   5 5 1 16.1
   5 5 2 16.2
   5 5 3 16.3
   5 5 4 16.2
   5 6 1 16.1
   5 6 2 16.1
   5 6 3 16.0
   5 6 4 16.1
   6 1 1 15.5
   6 1 2 15.5
   6 1 3 15.3
   6 1 4 15.6
   6 2 1 16.0
   6 2 2 15.6
   6 2 3 15.7
   6 2 4 16.2
   6 3 1 16.0
   6 3 2 16.4
   6 3 3 16.2
   6 3 4 16.2
   6 4 1 15.8
   6 4 2 16.5
   6 4 3 16.2
   6 4 4 16.2
   6 5 1 15.9
   6 5 2 16.1
   6 5 3 15.9
   6 5 4 16.0
   6 6 1 15.9
   6 6 2 16.1
   6 6 3 15.8
   6 6 4 15.7
   6 7 1 16.0
   6 7 2 16.4
   6 7 3 16.0
   6 7 4 16.0
   6 8 1 16.1
   6 8 2 16.2
   6 8 3 16.2
   6 8 4 16.1
;
* Plot standardized residuals versus predicted values for all data;
PROC GLM;
  CLASS A B C;
  MODEL VOLTG = A B C(B);
  RANDOM C(B) / TEST;
  LSMEANS A / PDIFF = ALL CL ADJUST = TUKEY;
  LSMEANS B / PDIFF = ALL CL ADJUST = TUKEY E = C(B);
  OUTPUT OUT = RESIDS PREDICTED = PRED RESIDUAL = Z;
PROC STANDARD STD=1.0;
  VAR Z;
PROC PLOT;
  PLOT Z*PRED = A Z*PRED = B Z*PRED = C / VREF = 0 VPOS = 19 HPOS = 50;
;
* Analysis without two outliers;
DATA VLT2; SET VLT;
  IF B = 2 AND C = 2 AND A = 1 THEN DELETE;
  IF B = 5 AND C = 3 AND A = 2 THEN DELETE;
PROC GLM;
  CLASS A B C;
  MODEL VOLTG = A B C(B);
  RANDOM C(B) / TEST;
  LSMEANS A / PDIFF = ALL CL ADJUST = TUKEY;
  * The following should be approximately correct;
  LSMEANS B / PDIFF = ALL CL ADJUST = TUKEY E = C(B);
PROC MIXED METHOD = TYPE3;
  CLASS A B C;
  MODEL VOLTG = A B / DDFM = SAT;
  RANDOM C(B);
  LSMEANS A B / CL PDIFF ADJUST = BON;
;
run;
