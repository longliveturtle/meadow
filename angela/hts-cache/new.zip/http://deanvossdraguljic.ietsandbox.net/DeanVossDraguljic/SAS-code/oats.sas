* oats.sas, oats experiment, Table 19.15, p728;
;
DATA OAT;
  INPUT BLOCK WP A B Y;
  LINES;
   1 1  2 3  156
   1 1  2 2  118
   1 1  2 1  140
   1 1  2 0  105
   1 2  0 0  111
   1 2  0 1  130
   1 2  0 3  174
   1 2  0 2  157
   1 3  1 0  117
   1 3  1 1  114
   1 3  1 2  161
   1 3  1 3  141
   2 1  2 2  109
   2 1  2 3   99
   2 1  2 0   63
   2 1  2 1   70
   2 2  1 0   80
   2 2  1 2   94
   2 2  1 3  126
   2 2  1 1   82
   2 3  0 1   90
   2 3  0 2  100
   2 3  0 3  116
   2 3  0 0   62
   3 1  2 2  104
   3 1  2 0   70
   3 1  2 1   89
   3 1  2 3  117
   3 2  0 3  122
   3 2  0 0   74
   3 2  0 1   89
   3 2  0 2   81
   3 3  1 1  103
   3 3  1 0   64
   3 3  1 2  132
   3 3  1 3  133
   4 1  1 3   96
   4 1  1 0   60
   4 1  1 2   89
   4 1  1 1  102
   4 2  0 2  112
   4 2  0 3   86
   4 2  0 0   68
   4 2  0 1   64
   4 3  2 2  132
   4 3  2 3  124
   4 3  2 1  129
   4 3  2 0   89
   5 1  1 1  108
   5 1  1 2  126
   5 1  1 3  149
   5 1  1 0   70
   5 2  2 3  144
   5 2  2 1  124
   5 2  2 2  121
   5 2  2 0   96
   5 3  0 0   61
   5 3  0 3  100
   5 3  0 1   91
   5 3  0 2   97
   6 1  0 2  118
   6 1  0 0   53
   6 1  0 3  113
   6 1  0 1   74
   6 2  1 3  104
   6 2  1 2   86
   6 2  1 0   89
   6 2  1 1   82
   6 3  2 0   97
   6 3  2 1   99
   6 3  2 2  119
   6 3  2 3  121
;
*** Analysis of variance: type I;
ods exclude estfunc; * Suppress some unwanted output;
PROC GLM;
  CLASS BLOCK A B WP;
  MODEL Y = BLOCK A WP(BLOCK) B A*B / E1;
  RANDOM BLOCK WP(BLOCK) / TEST;
  MEANS A / DUNNETT('0') CLDIFF ALPHA = 0.01;
  * The following statement fails to generate output due to
    nonestimability;
  LSMEANS A / ADJUST = DUNNETT ALPHA = 0.01 CL PDIFF = CONTROL('0')
              E = WP(BLOCK);
  LSMEANS B / ADJUST = DUNNETT ALPHA = 0.01 CL PDIFF = CONTROL('0');
;
PROC MIXED METHOD = TYPE1;
  CLASS BLOCK A B WP;
  MODEL Y = A B A*B / DDFM = SAT;
  RANDOM BLOCK WP(BLOCK);
  LSMEANS A B / PDIFF = CONTROL('0', '0')
  CL DIFF ADJUST = DUNNETT ALPHA = 0.01;
;
*** Analysis of variance: type III;
PROC GLM;
  CLASS BLOCK A B;
  MODEL Y = BLOCK A BLOCK*A B A*B;
  RANDOM BLOCK A*BLOCK / TEST;
  LSMEANS A / ADJUST = DUNNETT ALPHA = 0.01 CL PDIFF = CONTROL('0')
              E = BLOCK*A;
  LSMEANS B / ADJUST = DUNNETT ALPHA = 0.01 CL PDIFF = CONTROL('0');
;
PROC MIXED METHOD = TYPE3;
  CLASS BLOCK A B;
  MODEL Y = A B A*B / DDFM = SAT;
  RANDOM BLOCK A*BLOCK;
  LSMEANS A B / PDIFF = CONTROL('0', '0')
  CL DIFF ADJUST = DUNNETT ALPHA = 0.01;
;
run;
