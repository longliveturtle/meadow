* PAH.sas, PAH recovery experiment, Table 16.16, p596;
;
DATA PAH;
  INPUT RUN B1 B2 PRES TEMP   ET MC     Y;
  LINES;
         1   1  0  250   55 47.5 15 391.8
         2   1  0  150   85 47.5 15 413.6
         3   1  0  250   55 22.5  5  68.7
         4   1  0  250   85 47.5  5 143.0
         5   1  0  150   85 22.5  5 104.0
         6   1  0  150   55 22.5 15 309.1
         7   1  0  200   70 35.0 10 400.6
         8   1  0  250   85 22.5 15 402.5
         9   1  0  150   55 47.5  5  77.7
        10   1  0  200   70 35.0 10 426.5
        11   0  1  250   85 47.5 15 457.5
        12   0  1  150   55 22.5  5  56.9
        13   0  1  250   85 22.5  5  94.1
        14   0  1  250   55 22.5 15 409.7
        15   0  1  150   55 47.5 15 410.9
        16   0  1  150   85 22.5 15 375.8
        17   0  1  150   85 47.5  5 110.5
        18   0  1  200   70 35.0 10 387.8
        19   0  1  250   55 47.5  5 103.0
        20   0  1  200   70 35.0 10 399.1
        21  -1 -1  200   70 35.0 10 416.9
        22  -1 -1  200   40 35.0 10 359.8
        23  -1 -1  200   70 10.0 10 276.1
        24  -1 -1  200   70 60.0 10 462.3
        25  -1 -1  100   70 35.0 10 311.5
        26  -1 -1  200   70 35.0 10 346.5
        27  -1 -1  200   70 35.0  0  46.8
        28  -1 -1  200   70 35.0 20 418.7
        29  -1 -1  200  100 35.0 10 413.9
        30  -1 -1  300   70 35.0 10 429.4
;
* Sort by independent variables for lack of fit test;
PROC SORT; BY B1 B2 PRES TEMP ET MC;
;
* Response surface regression, including contour plots;
ODS GRAPHICS ON; * Needed for contour plots; 
PROC RSREG PLOTS = SURFACE;
  MODEL Y = B1 B2 PRES TEMP ET MC / COVAR = 2 LACKFIT;
  RUN;
ODS GRAPHICS OFF;
;
run;
