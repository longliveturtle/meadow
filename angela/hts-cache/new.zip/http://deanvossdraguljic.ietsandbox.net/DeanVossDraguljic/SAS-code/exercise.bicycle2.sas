* exercise.bicycle2.sas, exercise bicycle experiment, Table 12.11, p420;
;
DATA BIKE;
  INPUT DAY SUBJECT PULSE DURAT$ SPEED$ PEDAL$;
  TRTMT = trim(DURAT)||trim(SPEED)||trim(PEDAL);
  LINES;
   1 1  45  1 1 2
   1 2  25  2 1 2
   1 3  18  2 2 1
   2 1  27  2 2 2
   2 2  20  2 1 1
   2 3  32  2 1 2
   3 1  40  2 1 2
   3 2  23  2 2 2
   3 3  28  1 1 2
   4 1  17  2 2 1
   4 2  32  1 1 2
   4 3  24  1 2 2
   5 1  30  2 1 1
   5 2  36  1 1 1
   5 3  20  2 2 2
   6 1  29  1 2 2
   6 2  13  2 2 1
   6 3  20  1 2 1
   7 1  34  1 1 1
   7 2  18  1 2 1
   7 3  25  2 1 1
   8 1  21  1 2 1
   8 2  22  1 2 2
   8 3  34  1 1 1
;
* Add the following code for the second run of the program;
DATA BIKE3; * input subject effect estimates from first run;
  INPUT SUBJECT SHAT @@;
  LINES;
   1 5.25 2 -1.50 3 0.00
PROC MEANS MEAN; * print average of the subject effect estimates;
  VAR SHAT;
DATA BIKE4; * input day effect estimates from first run;
  INPUT DAY DHAT @@;
  LINES;
   1 3.9911 2 1.5625 3 2.5714 4 0.8036
   5 2.5179 6 1.6334 7 0.2054 8 0.0000
PROC MEANS MEAN; * print average of the day effect estimates;
  VAR DHAT;
* Add the following code for the third run;
* Adjust data for subject and day effects, then plot adjusted data;
DATA BIKE5; SET BIKE;
  IF SUBJECT = 1 THEN YADJ = PULSE-(5.25-1.25);
    ELSE IF SUBJECT = 2 THEN YADJ = PULSE-(-1.50-1.25);
      ELSE IF SUBJECT = 3 THEN YADJ = PULSE-(0.00-1.25);
  IF DAY = 1 THEN YADJ = YADJ-(3.9911-1.660);
    ELSE IF DAY = 2 THEN YADJ = YADJ-(1.5625-1.6607);
      ELSE IF DAY = 3 THEN YADJ = YADJ-(2.5714-1.6607);
        ELSE IF DAY = 4 THEN YADJ = YADJ-(0.8036-1.6607);
          ELSE IF DAY = 5 THEN YADJ = YADJ-(2.5179-1.6607);
            ELSE IF DAY = 6 THEN YADJ = YADJ-(1.6334-1.6607);
              ELSE IF DAY = 7 THEN YADJ = YADJ-(0.2054-1.6607);
                ELSE IF DAY = 8 THEN YADJ = YADJ-(0.0000-1.6607);
run;

PROC SGPLOT;
  SCATTER X = TRTMT Y = YADJ;
  XAXIS LABEL = 'Treatment'; 
  YAXIS LABEL = 'Adjusted Observations'; 

run;
