* oats2.sas, oats experiment, Table 19.20, p739;
;
DATA OATBIBD;
  INPUT BLOCK WP A B Y;
  IF A = 0 AND (BLOCK = 3 OR BLOCK = 5) THEN DELETE;
  IF A = 1 AND (BLOCK = 1 OR BLOCK = 4) THEN DELETE;
  IF A = 2 AND (BLOCK = 2 OR BLOCK = 6) THEN DELETE;
  LINES;
   1 1  2 3  156
   1 1  2 2  118
   1 1  2 1  140
   1 1  2 0  105
   1 2  0 0  111
   1 2  0 1  130
   1 2  0 3  174
   1 2  0 2  157
   1 3  1 0  117
   1 3  1 1  114
   1 3  1 2  161
   1 3  1 3  141
   2 1  2 2  109
   2 1  2 3   99
   2 1  2 0   63
   2 1  2 1   70
   2 2  1 0   80
   2 2  1 2   94
   2 2  1 3  126
   2 2  1 1   82
   2 3  0 1   90
   2 3  0 2  100
   2 3  0 3  116
   2 3  0 0   62
   3 1  2 2  104
   3 1  2 0   70
   3 1  2 1   89
   3 1  2 3  117
   3 2  0 3  122
   3 2  0 0   74
   3 2  0 1   89
   3 2  0 2   81
   3 3  1 1  103
   3 3  1 0   64
   3 3  1 2  132
   3 3  1 3  133
   4 1  1 3   96
   4 1  1 0   60
   4 1  1 2   89
   4 1  1 1  102
   4 2  0 2  112
   4 2  0 3   86
   4 2  0 0   68
   4 2  0 1   64
   4 3  2 2  132
   4 3  2 3  124
   4 3  2 1  129
   4 3  2 0   89
   5 1  1 1  108
   5 1  1 2  126
   5 1  1 3  149
   5 1  1 0   70
   5 2  2 3  144
   5 2  2 1  124
   5 2  2 2  121
   5 2  2 0   96
   5 3  0 0   61
   5 3  0 3  100
   5 3  0 1   91
   5 3  0 2   97
   6 1  0 2  118
   6 1  0 0   53
   6 1  0 3  113
   6 1  0 1   74
   6 2  1 3  104
   6 2  1 2   86
   6 2  1 0   89
   6 2  1 1   82
   6 3  2 0   97
   6 3  2 1   99
   6 3  2 2  119
   6 3  2 3  121
;
*** Intra-block analyses;
PROC MIXED METHOD = TYPE3;
  TITLE 'ANOVA Approach, Type 3, Fixed Block Effects';
  CLASS BLOCK A B;
  MODEL Y = BLOCK A B A*B / DDFM = SAT;
  RANDOM A*BLOCK; * Random whole-plot effects;
  LSMEANS A / PDIFF = CONTROL('0') CL DIFF ADJUST = DUNNETT ALPHA = 0.01;
;
PROC MIXED METHOD = ReML NOBOUND;
  TITLE 'ReML Approach, Fixed Block Effects';
  CLASS BLOCK A B WP;
  MODEL Y = BLOCK A B A*B / DDFM = SAT;
  RANDOM WP(BLOCK);
  LSMEANS A / PDIFF = CONTROL('0') CL DIFF ADJUST = DUNNETT ALPHA = 0.01;
  *** Analyses recovering inter-block information;
;
PROC MIXED METHOD = TYPE3;
  TITLE 'ANOVA Approach, Type 3, Random Block Effects';
  CLASS BLOCK A B;
  MODEL Y = A B A*B / DDFM = SAT;
  RANDOM BLOCK A*BLOCK;
  LSMEANS A / PDIFF = CONTROL('0') CL DIFF ADJUST = DUNNETT ALPHA = 0.01;
;
PROC MIXED METHOD = ReML NOBOUND;
  TITLE 'ReML Approach, Random Block Effects';
  CLASS BLOCK A B WP;
  MODEL Y = A B A*B / DDFM = SAT;
  RANDOM BLOCK WP(BLOCK);
  LSMEANS A / PDIFF = CONTROL('0') CL DIFF ADJUST = DUNNETT ALPHA = 0.01;
;
run;
