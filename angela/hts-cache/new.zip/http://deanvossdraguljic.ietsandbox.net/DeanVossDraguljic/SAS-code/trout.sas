* trout.sas, trout experiment, Table 5.10, p125;
;
DATA TROUT;
  INPUT SULFA HEMO;
  LINES;
  1  6.7
  1  7.8
  1  5.5
  1  8.4
  1  7.0
  1  7.8
  1  8.6
  1  7.4
  1  5.8
  1  7.0
  2  9.9
  2  8.4
  2 10.4
  2  9.3
  2 10.7
  2 11.9
  2  7.1
  2  6.4
  2  8.6
  2 10.6
  3 10.4
  3  8.1
  3 10.6
  3  8.7
  3 10.7
  3  9.1
  3  8.8
  3  8.1
  3  7.8
  3  8.0
  4  9.3
  4  9.3
  4  7.2
  4  7.8
  4  9.3
  4 10.2
  4  8.7
  4  8.6
  4  9.3
  4  7.2
;
PROC MIXED;
  CLASS SULFA;
  MODEL HEMO = SULFA / DDFM=SATTERTH;
  REPEATED / GROUP=SULFA;
  LSMEANS SULFA / ADJDFE=ROW ADJUST=TUKEY;
;
run;