* coil.sas, coil experiment, Table 13.20, p461;
;
DATA COIL;
  INPUT BLOCK A B C Y;
  LINES;
   1  0 0 0 2208
   1  1 1 0 2133
   1  1 0 1 2459
   1  0 1 1 3096
   2  1 0 0 2196
   2  0 1 0 2086
   2  0 0 1 3356
   2  1 1 1 2776
   3  0 0 0 2004
   3  1 1 0 2112
   3  0 0 1 3073
   3  1 1 1 2631
   4  1 0 0 2179
   4  0 1 0 2073
   4  1 0 1 3474
   4  0 1 1 3360
   5  0 0 1 2839
   5  1 0 0 2189
   5  0 1 1 3522
   5  1 1 0 2095
   6  0 0 0 1916
   6  1 0 1 2979
   6  0 1 0 2151
   6  1 1 1 2500
   7  1 0 0 2056
   7  0 0 0 2010
   7  0 1 1 3209
   7  1 1 1 3066
   8  0 1 0 1878
   8  1 1 0 2156
   8  0 0 1 3423
   8  1 0 1 2524
;
PROC GLM;
  CLASS BLOCK A B C;
  MODEL Y = BLOCK A B C A*B A*C B*C A*B*C;
  ESTIMATE 'A' A -1 1;
  ESTIMATE 'B' B -1 1;
  ESTIMATE 'C' C -1 1;
  ESTIMATE 'AB' A*B 1 -1 -1 1 / DIVISOR=2;
  ESTIMATE 'AC' A*C 1 -1 -1 1 / DIVISOR=2;
  ESTIMATE 'BC' B*C 1 -1 -1 1 / DIVISOR=2;
  ESTIMATE 'ABC' A*B*C -1 1 1 -1 1 -1 -1 1 / DIVISOR=4;
;
run;
