* cotton.spinning.sas, cotton-spinning experiment, Table 10.13, p328;
;
DATA COTTON;
  INPUT BLOCK TRTMT FLYER TWIST BREAK;
  LINES;
   1 12 1 1.69  6.0
   2 12 1 1.69  9.7
   3 12 1 1.69  7.4
   4 12 1 1.69 11.5
   5 12 1 1.69 17.9
   6 12 1 1.69 11.9
   1 13 1 1.78  6.4
   2 13 1 1.78  8.3
   3 13 1 1.78  7.9
   4 13 1 1.78  8.8
   5 13 1 1.78 10.1
   6 13 1 1.78 11.5
   1 14 1 1.90  2.3
   2 14 1 1.90  3.3
   3 14 1 1.90  7.3
   4 14 1 1.90 10.6
   5 14 1 1.90  7.9
   6 14 1 1.90  5.5
   1 21 2 1.63  3.3
   2 21 2 1.63  6.4
   3 21 2 1.63  4.1
   4 21 2 1.63  6.9
   5 21 2 1.63  6.0
   6 21 2 1.63  7.4
   1 22 2 1.69  3.7
   2 22 2 1.69  6.4
   3 22 2 1.69  8.3
   4 22 2 1.69  3.3
   5 22 2 1.69  7.8
   6 22 2 1.69  5.9
   1 23 2 1.78  4.2
   2 23 2 1.78  4.6
   3 23 2 1.78  5.0
   4 23 2 1.78  4.1
   5 23 2 1.78  5.5
   6 23 2 1.78  3.2
   7 12 1 1.69 10.2
   8 12 1 1.69  7.8
   9 12 1 1.69 10.6
  10 12 1 1.69 17.5
  11 12 1 1.69 10.6
  12 12 1 1.69 10.6
  13 12 1 1.69  8.7
   7 13 1 1.78  8.7
   8 13 1 1.78  9.7
   9 13 1 1.78  8.3
  10 13 1 1.78  9.2
  11 13 1 1.78  9.2
  12 13 1 1.78 10.1
  13 13 1 1.78 12.4
   7 14 1 1.90  7.8
   8 14 1 1.90  5.0
   9 14 1 1.90  7.8
  10 14 1 1.90  6.4
  11 14 1 1.90  8.3
  12 14 1 1.90  9.2
  13 14 1 1.90 12.0
   7 21 2 1.63  6.0
   8 21 2 1.63  7.3
   9 21 2 1.63  7.8
  10 21 2 1.63  7.4
  11 21 2 1.63  7.3
  12 21 2 1.63 10.1
  13 21 2 1.63  7.8
   7 22 2 1.69  8.3
   8 22 2 1.69  5.1
   9 22 2 1.69  6.0
  10 22 2 1.69  3.7
  11 22 2 1.69 11.5
  12 22 2 1.69 13.8
  13 22 2 1.69  8.3
   7 23 2 1.78 10.1
   8 23 2 1.78  4.2
   9 23 2 1.78  5.1
  10 23 2 1.78  4.6
  11 23 2 1.78 11.5
  12 23 2 1.78  5.0
  13 23 2 1.78  6.4
;
* Block-treatment model for a complete block design;
PROC GLM;
  CLASS BLOCK TRTMT;
  MODEL BREAK = BLOCK TRTMT;
  LSMEANS TRTMT / PDIFF = ALL CL ADJUST = TUKEY ALPHA = 0.05;
  ESTIMATE 'FLYER 1-2 COMN TWST' TRTMT 0.5 0.5 0 0 -0.5 -0.5;
  ESTIMATE 'LIN TWIST ORD FLYER' TRTMT -10 -1 11 0 0 0;
;
* Factorial main effects model plus blocks;
PROC GLM;
  CLASS BLOCK FLYER TWIST;
  MODEL BREAK = BLOCK FLYER TWIST;
  LSMEANS FLYER / PDIFF CL ALPHA=0.05;
  LSMEANS TWIST / PDIFF = ALL CL ADJUST = BON ALPHA = 0.05;
;
* Model with twist as a linear regressor variable;
PROC GLM;
  CLASS BLOCK FLYER;
  MODEL BREAK = BLOCK FLYER TWIST / SOLUTION;
  ESTIMATE 'FLYER 1-2' FLYER 1 -1;
;
* Testing lack of fit of reduced model;
PROC GLM;
  CLASS BLOCK FLYER TRTMT;
  MODEL BREAK = BLOCK FLYER TWIST TRTMT;
;
run;
