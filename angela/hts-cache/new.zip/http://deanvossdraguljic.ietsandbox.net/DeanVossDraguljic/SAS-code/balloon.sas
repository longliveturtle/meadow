* balloon.sas, balloon experiment, Table 9.5, p297;
;
DATA;
  INPUT RUNORDER COLOR INFTIME;
  X = RUNORDER - 16.5;
  LINES;
      1 1 22.0
      2 3 24.6
      3 1 20.3
      4 4 19.8
      5 3 24.3
      6 2 22.2
      7 2 28.5
      8 2 25.7
      9 3 20.2
     10 1 19.6
     11 2 28.8
     12 4 24.0
     13 4 17.1
     14 4 19.3
     15 3 24.2
     16 1 15.8
     17 2 18.3
     18 1 17.5
     19 4 18.7
     20 3 22.9
     21 1 16.3
     22 4 14.0
     23 4 16.6
     24 2 18.1
     25 2 18.9
     26 4 16.0
     27 2 20.1
     28 3 22.5
     29 3 16.0
     30 1 19.3
     31 1 15.9
     32 3 20.3
;
PROC GLM;
  CLASS COLOR;
  MODEL INFTIME = COLOR X;
  ESTIMATE '1-2' COLOR 1 -1  0  0;
  ESTIMATE '1-3' COLOR 1  0 -1  0;
  ESTIMATE '1-4' COLOR 1  0  0 -1;
  ESTIMATE '2-3' COLOR 0  1 -1  0;
  ESTIMATE '2-4' COLOR 0  1  0 -1;
  ESTIMATE '3-4' COLOR 0  0  1 -1;
  ESTIMATE 'BETA' X 1;
  OUTPUT OUT=B P=PRED R=Z;
;
PROC STANDARD STD=1;
  VAR Z;
PROC RANK NORMAL=BLOM OUT=C;
  VAR Z;
  RANKS NSCORE;
;
PROC SGPLOT;
  SCATTER Y = Z X = RUNORDER;
  YAXIS VALUES = (-2 TO 2 BY 1);
  XAXIS LABEL = "Run Order" VALUES = (0 TO 35 BY 5);
PROC SGPLOT; SCATTER Y = Z X = PRED;
PROC SGPLOT; SCATTER Y = Z X = COLOR;
PROC SGPLOT; SCATTER Y = Z X = NSCORE;
;
run;