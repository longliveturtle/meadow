* inclinometer.sas, inclinometer experiment -- product array analysis, 
* Table 15.43, p542;
;
DATA INCLP;
  INPUT A B C D E F G Y1 Y2 Y3 Y4 Y5 Y6 Y7 Y8;
  AVY = (Y1 + Y2 + Y3 + Y4 + Y5 + Y6 + Y7 + Y8)/8;
  VAR = ((Y1*Y1 + Y2*Y2 + Y3*Y3 + Y4*Y4 + Y5*Y5 + Y6*Y6
                        + Y7*Y7 + Y8*Y8) - 8*AVY*AVY)/7;
  LNVAR = LOG(VAR);
  LINES;
  0 0 0 0 0 0 0 0.62 3.54 3.56 0.62 3.09 0.71 0.73 3.20 
  0 0 1 1 1 1 1 0.59 3.11 3.11 0.59 2.98 0.63 0.64 3.02 
  0 0 2 2 2 2 2 0.59 3.01 3.02 0.59 2.97 0.61 0.62 3.00 
  0 1 0 1 1 2 2 0.51 2.65 2.65 0.50 2.53 0.53 0.54 2.56 
  0 1 1 2 2 0 0 0.18 0.96 0.96 0.18 0.89 0.19 0.20 0.90 
  0 1 2 0 0 1 1 1.88 9.58 9.55 1.85 9.30 1.92 1.94 9.48 
  0 2 0 2 2 1 1 0.19 1.03 1.03 0.19 0.97 0.21 0.21 0.93 
  0 2 1 0 0 2 2 1.85 9.46 9.42 1.82 9.19 1.90 1.92 9.35 
  0 2 2 1 1 0 0 0.52 2.73 2.72 0.51 2.61 0.55 0.56 2.64 
  1 0 0 1 2 1 2 0.29 1.56 1.56 0.29 1.45 0.31 0.32 1.47 
  1 0 1 2 0 2 0 0.95 4.98 4.93 0.94 4.79 0.99 1.00 4.82 
  1 0 2 0 1 0 1 1.16 6.09 6.09 1.13 5.70 1.21 1.26 5.93 
  1 1 0 2 0 0 1 0.26 1.45 1.45 0.25 1.30 0.29 0.30 1.30 
  1 1 1 0 1 1 2 1.15 5.99 5.92 1.13 5.69 1.19 1.22 5.84 
  1 1 2 1 2 2 0 0.85 4.31 4.30 0.84 4.23 0.86 0.88 4.28 
  1 2 0 0 1 2 0 1.10 5.74 5.67 1.07 5.43 1.14 1.17 5.57 
  1 2 1 1 2 0 1 0.29 1.55 1.55 0.28 1.45 0.31 0.32 1.47 
  1 2 2 2 0 1 2 0.91 4.64 4.66 0.90 4.56 0.94 0.95 4.57 
  2 0 0 2 1 2 1 0.39 2.05 2.06 0.39 1.96 0.41 0.42 1.97 
  2 0 1 0 2 0 2 0.67 3.61 3.57 0.65 3.27 0.72 0.74 3.41 
  2 0 2 1 0 1 0 1.42 7.31 7.38 1.41 7.14 1.48 1.51 7.24 
  2 1 0 0 2 1 0 0.69 3.66 3.60 0.67 3.37 0.73 0.74 3.47 
  2 1 1 1 0 2 1 1.18 6.04 6.06 1.17 5.90 1.21 1.23 5.95 
  2 1 2 2 1 0 2 0.37 1.95 1.95 0.37 1.87 0.39 0.40 1.88 
  2 2 0 1 0 0 2 0.39 2.15 2.16 0.38 1.94 0.44 0.44 1.96 
  2 2 1 2 1 1 0 0.44 2.29 2.29 0.43 2.21 0.46 0.47 2.22 
  2 2 2 0 2 2 1 1.84 9.35 9.19 1.79 9.06 1.85 1.89 9.28
;
* Analysis of the log sample variance;
PROC GLM;
  CLASS A B C D E F G;
  MODEL LNVAR = A B C D E F G;
  ESTIMATE 'Lin A'  A -1  0  1;
  ESTIMATE 'Quad A' A  1 -2  1;
  ESTIMATE 'Lin B'  B -1  0  1;
  ESTIMATE 'Quad B' B  1 -2  1;
  ESTIMATE 'Lin C'  C -1  0  1;
  ESTIMATE 'Quad C' C  1 -2  1;
  ESTIMATE 'Lin D'  D -1  0  1;
  ESTIMATE 'Quad D' D  1 -2  1;
  ESTIMATE 'Lin E'  E -1  0  1;
  ESTIMATE 'Quad E' E  1 -2  1;
  ESTIMATE 'Lin F'  F -1  0  1;
  ESTIMATE 'Quad F' F  1 -2  1;
  CONTRAST 'Lin A'  A -1  0  1;
  CONTRAST 'Quad A' A  1 -2  1;
  CONTRAST 'Lin B'  B -1  0  1;
  CONTRAST 'Quad B' B  1 -2  1;
  CONTRAST 'Lin C'  C -1  0  1;
  CONTRAST 'Quad C' C  1 -2  1;
  CONTRAST 'Lin D'  D -1  0  1;
  CONTRAST 'Quad D' D  1 -2  1;
  CONTRAST 'Lin E'  E -1  0  1;
  CONTRAST 'Quad E' E  1 -2  1;
  CONTRAST 'Lin F'  F -1  0  1;
  CONTRAST 'Quad F' F  1 -2  1;
  LSMEANS A B C D E F G;
;
* Analysis of the sample mean;
PROC GLM;
  CLASS A B C D E F G;
  MODEL AVY = A B C D E F G;
  ESTIMATE 'Lin A'  A -1  0  1;
  ESTIMATE 'Quad A' A  1 -2  1;
  ESTIMATE 'Lin B'  B -1  0  1;
  ESTIMATE 'Quad B' B  1 -2  1;
  ESTIMATE 'Lin C'  C -1  0  1;
  ESTIMATE 'Quad C' C  1 -2  1;
  ESTIMATE 'Lin D'  D -1  0  1;
  ESTIMATE 'Quad D' D  1 -2  1;
  ESTIMATE 'Lin E'  E -1  0  1;
  ESTIMATE 'Quad E' E  1 -2  1;
  ESTIMATE 'Lin F'  F -1  0  1;
  ESTIMATE 'Quad F' F  1 -2  1;
  CONTRAST 'Lin A'  A -1  0  1;
  CONTRAST 'Quad A' A  1 -2  1;
  CONTRAST 'Lin B'  B -1  0  1;
  CONTRAST 'Quad B' B  1 -2  1;
  CONTRAST 'Lin C'  C -1  0  1;
  CONTRAST 'Quad C' C  1 -2  1;
  CONTRAST 'Lin D'  D -1  0  1;
  CONTRAST 'Quad D' D  1 -2  1;
  CONTRAST 'Lin E'  E -1  0  1;
  CONTRAST 'Quad E' E  1 -2  1;
  CONTRAST 'Lin F'  F -1  0  1;
  CONTRAST 'Quad F' F  1 -2  1;
  LSMEANS A B C D E F G;
;
run;
