* rail.weld.sas, rail weld experiment, Table 7.10, p229;
;
DATA;
  INPUT T V S Y1 Y2;
  REP = 1; Y = Y1; OUTPUT; * create SAS observation for y = y1;
  REP = 2; Y = Y2; OUTPUT; * create SAS observation for y = y2;
  LINES;
  1 1 1 84.0 91.0
  1 1 2 77.7 80.5
  2 1 1 95.5 84.0
  2 1 2 99.7 95.4
  2 2 1 76.0 98.0
  2 2 2 93.7 81.7
;
PROC PRINT;
  VAR T V S REP Y;
;
* Try to fit a 3-way complete model;
PROC GLM;
  CLASS T V S;
  MODEL Y = T | V | S;
  ESTIMATE 'TEMPERATURE' T -1 1;
;
* Fit a sub-model using 5 degrees of freedom;
PROC GLM;
  CLASS T V S;
  MODEL Y = T V S T*S V*S;
  ESTIMATE 'TEMPERATURE' T -1 1;
  ESTIMATE 'VELOCITY' V -1 1;
  ESTIMATE 'SIZE' S -1 1;
  ESTIMATE 'TEMPERATURE*SIZE' T*S 1 -1 -1 1 / DIVISOR = 2;
  ESTIMATE 'VELOCITY*SIZE' V*S 1 -1 -1 1 / DIVISOR = 2;
;
run;