* mung.bean.sas, mung bean experiment, Table 5.8, p121;
;
DATA MUNGBEAN;
  INPUT ORDER WATER MEDIUM LENGTH;
  TRTMT = 2*(WATER-1) + MEDIUM;
  LINES;
   1  2  2  13.2
   2  3  2  11.6
   3  1  2   0.0
   4  1  2   0.6
   5  3  1   5.1
   6  3  2   2.3
   7  1  2   9.5
   8  3  2   6.7
   9  3  2   2.5
  10  3  2  10.6
  11  2  2  14.8
  12  1  2  11.3
  13  2  2  10.7
  14  1  1   1.5
  15  1  1   1.1
  16  2  1   5.2
  17  1  2  12.6
  18  1  1   1.3
  19  3  2  10.8
  20  2  2  13.8
  21  3  1   3.3
  22  3  2  15.9
  23  2  1   0.4
  24  2  2   9.6
  25  3  2   9.0
  26  3  1   0.2
  27  1  2   8.1
  28  3  1   3.9
  29  1  2   7.8
  30  1  1   0.9
  31  2  1   3.6
  32  3  1   7.0
  33  3  1   9.5
  34  2  2   0.0
  35  1  1   8.5
  36  2  1   2.8
  37  1  2   7.3
  38  3  1  11.1
  39  1  1  10.6
  40  2  2   0.6
  41  3  1   6.2
  42  1  1   3.5
  43  1  1   7.4
  44  2  2   8.2
  45  2  1  12.3
  46  2  1  14.1
  47  2  1   0.3
  48  2  1   1.8
;
PROC GLM;
  CLASS TRTMT;
  MODEL LENGTH = TRTMT;
  OUTPUT OUT=MUNGBN2 PREDICTED=YPRED RESIDUAL=E RESIDUAL=Z;
;
PROC STANDARD STD=1.0; VAR Z;
PROC RANK NORMAL=BLOM; VAR Z; RANKS NSCORE;
PROC PRINT;
;
* Plotting standardized residuals versus run order;
PROC SGPLOT;
  SCATTER X=ORDER Y=Z;
  XAXIS LABEL = 'Order';
  YAXIS LABEL = 'Standardized Residuals';
  REFLINE 0 / AXIS=Y;
;
* Plotting standardized residuals versus normal scores;
PROC SGPLOT;
  SCATTER X=NSCORE Y=Z;
  XAXIS VALUES = (-4 to 4 by 2) LABEL = 'Normal Scores';
  YAXIS LABEL = 'Standardized Residuals';
  REFLINE 0 / AXIS=Y;
  REFLINE 0 / AXIS=X;
;
run;