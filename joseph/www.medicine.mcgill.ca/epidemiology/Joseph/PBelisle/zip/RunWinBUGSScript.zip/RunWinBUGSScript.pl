# >>> RunWinBUGSScript version 2.0 <<<
#                (Released September 2015)
#
# This program was written by
# ---------------------------
# Patrick Belisle
# Division of Clinical Epidemiology
# McGill University Health Centre
# Montreal, Qc CANADA
# patrick.belisle@clinepi.mcgill.ca

# For instructions on how to use this pgm, please visit
# http://www.medicine.mcgill.ca/epidemiology/Joseph/PBelisle/RunWinBUGSScript.html


# ---- Do not edit below this line --------------------------------------------------------------------------------------------------

$OUTPUT_AUTOFLUSH = 1;

use strict;
use Win32;
use File::Copy;



our %Max = (codaLPath  => 114,
            expNDigits =>   4, # max number of digits printed in node stats (when computing exp|inv.logit)
            wbLPath    => 119);

our %Min = (nDigitsInScientific => 3);

our $MEDIANCOL   = 5;
our @CICOLS      = (4, 6);
our @NITERNSCOLS = (7, 8);

# our %My = (WinBUGS=> {path => "C:/Program Files (x86)/WinBUGS14/WinBUGS14.exe"}); # change path on this line and uncomment


our %Tmp = (dir    => Win32::GetShortPathName($ENV{TMP}),
            script => "_script.txt");

$Tmp{dir} =~ s{\\}{/}g;

foreach (keys %Tmp)
{
  next if $_ eq "dir";
  $Tmp{$_} = "$Tmp{dir}/$Tmp{$_}";
}


our %Instr = (CombinedNodeStatsNDigits => 4,
              prefix   => "_rwbs",
              undefFct => "->",
              WouldRun => 0 # when set to 1, simply gives the list of WinBUGS pgms that would be run (but does not actually run them));
             );


my $LOG = "$1.log" if $0 =~ /(.*)\./;
$LOG =~ s{\\+}{/}g;
open(STDERR, ">$LOG") || die "Cannot write to log file $LOG. Abort.\n";
print STDERR localtime() . "\n";

# ------------------------------------------------------------------------------
my $altname;
my $nmodelsrun;

our %altname;
our %codaFile;
our %Col2Fct;
our %Col2Keep4Fct;
our %ComputeExp;
our %ComputeInvLogit;
our %ComputeNodeStat;
our %DoNotMonitor;
our %DoNotMonitorIfVarnameStartsWith;
our %droppedvars;
our %factor;
our %monitored;
our $nChains;
our %ncodaFiles;
our %node;
our %NodeStat;
our %NodeStats;
our %srcdatafile;
our (%_wbsplogcmd, %_wbsplog2edit, %_wbspfile2rm, %_wbsprename);

my @Errors;
our @InputFiles;
my @NIter;
our @noExp;
my @Notes;
our @OutputFiles;
my @pgms;
my @wouldrun;
my @Warnings;

# ------------------------------------------------------------------------------

foreach ($MEDIANCOL, @CICOLS)
{
  $Col2Fct{$_} = 1;
}

foreach (@NITERNSCOLS)
{
  $Col2Keep4Fct{$_} = 1;
}

# --- Lecture des cmdline args -------------------------------------------------

while (@ARGV)
{
  $_ = shift;

  if (-f && -T _)
  {
    push(@pgms, $_) if -s _;
  }
  elsif (-d _)
  {
    my @tmp = (<$_/*.txt>);
    foreach (@tmp)
    {
      push(@pgms, $_) if -f && -T _ && -s _;
    }
  }
  elsif (/\*/)
  {
    my @tmp = (<${_}>);
    foreach (@tmp)
    {
      push(@pgms, $_) if -f && -T _ && -s _;
    }
  }
  elsif (/(\d+)(k?)/ && !$` && !$')
  {
    my $tmp;
    ($_, $tmp) = ($1, lc $2);
    $_ *= 1000 if $tmp eq "k";
    push(@NIter, $_);
  }
  elsif (/(\d+)(k?)\/(\d+)(k?)/ && !$` && !$')
  {
    my ($tmpburnin, $tmpk1, $tmpgibbs, $tmpk2) = ($1, lc $2, $3, lc $4);

    $tmpburnin *= 1000 if $tmpk1 eq "k";
    $tmpgibbs  *= 1000 if $tmpk2 eq "k";

    push(@NIter, $tmpburnin, $tmpgibbs);
  }
  elsif ($_ eq "-rmtmpinits")
  {
    $Instr{rmTmpInits} = 1;
  }
  elsif ($_ eq "-norerun" || $_ eq "-s")
  {
    $Instr{noRerun} = 1;
  }
  elsif ($_ eq "-skip")
  {
    $Instr{skip} = shift;
  }
  elsif ($_ eq "-list")
  {
    $Instr{WouldRun} = 1;
  }
  elsif ($_ eq "-dnm")
  {
    my $tmp = shift;
    my @tmp = split(",", $tmp);
    foreach (@tmp)
    {
      if (substr($_, -1) eq "*")
      {
        $_ = substr($_, 0, -1);
        $DoNotMonitorIfVarnameStartsWith{$_} = 1;
      }
      else
      {
        $DoNotMonitor{$_} = 1;
      }
    }
  }
}

# ------------------------------------------------------------------------------------

# See which files given in argument, or found in directories given in arguments,
# are WinBUGS scripts and, of these, which need not be resubmitted (as output files
# already exist and neither script nor input files were modified since)

my @candidates = @pgms;
undef @pgms;

foreach my $candidate (@candidates)
{
  $candidate =~ s{/}{\\}g;

  my ($altscript, $isScript, $run);

  ($isScript, $run, $altscript) = &Read($candidate);

  if ($run && defined $altscript)
  {
    $candidate = $altscript;
    redo;
  }

  unless ($isScript)
  {
    push(@Warnings, "$candidate:", "not a WinBUGS script", "");
    next;
  }

  if ($run)
  {
    # running is forced because one of the output file names was not clear (extension different from .txt or .odc)
    push(@pgms, $candidate);
    next;
  }

  # make sure that all input files are present

  my $missingInputfile;
  my $inputAge = -M $candidate;

  foreach (@InputFiles)
  {
    if (-e)
    {
      my $age = -M _;
      $inputAge = $age if $age < $inputAge;
    }
    else
    {
      $missingInputfile = $_;
      last;
    }
  }

  if ($missingInputfile)
  {
    push(@Errors, "$candidate:", "not run due to missing input file $missingInputfile", "");
    next;
  }

  my $outputAge;

  foreach (@OutputFiles)
  {
    if (-e)
    {
      my $age = -M _;
      $outputAge = $age if $age > $outputAge;
    }
    else
    {
      $run = 1;
    }
  }

  if ($run)
  {
    push(@pgms, $candidate);
    next;
  }

  if ($inputAge > $outputAge)
  {
    push(@Notes, "$candidate:", "no need to rerun as neither script nor any of the input files is younger than the already existing output file(s)", "");
    next;
  }

  push(@pgms, $candidate);
}


# ------------------------------------------------------------------------------------

&PrintSection("notes",    "_", @Notes)    if @Notes;
&PrintSection("warnings", "=", @Warnings) if @Warnings;
&PrintSection("errors",   "*", @Errors)   if @Errors;

# ------------------------------------------------------------------------------------


foreach my $pgm (@pgms)
{
  my $runWB = 1;
  my $time0 = time;

  # Read original script and see whether or not it needs to be resubmitted

  undef $nChains;

  undef @noExp;

  undef %altname;
  undef %codaFile;
  undef %ComputeExp;
  undef %ComputeInvLogit;
  undef %droppedvars;
  undef %factor;
  undef %monitored;
  undef %ncodaFiles;
  undef %node;
  undef %NodeStat;
  undef %NodeStats;
  undef %srcdatafile;

  my ($anydatachanged, $model, $nNodes, @script0, @unlink, @vars2drop);

  open(SCRIPT, $pgm) || die "Cannot read script in $pgm. Abort.\n";
  my @tmpscript0 = (<SCRIPT>);
  close SCRIPT;

  while (@tmpscript0)
  {
    $_ = shift @tmpscript0;

    if (/# when done, compute stats for exp\(\) of\:?\s*/)
    {
      &ReadExp($');
      next;
    }
    elsif (/# when done, compute stats for inv\.logit\(\) of\:?\s*/)
    {
      my @tmp = split(" ", $');
      foreach (@tmp)
      {
        undef $altname;
        ($_, $altname) = ($`, $') if /\-\>/;

        $ComputeInvLogit{$_} = 1;
        $node{$_} = $_;

        $altname{$_} = $altname if defined $altname;
      }
      next;
    }
    elsif (/#\s*RunWinBUGSScript will drop the following variable/)
    {
      $_ = shift @tmpscript0;
      s/#\s*//;
      chomp;
      @vars2drop = split;
    }
    else
    {
      s/#.*//; # IGNORE OTHER COMMENTS
      next unless /\S/;

      push(@script0, $_);

      if (/save\(\s*'(.*)'/)
      {
        my $f = $1;
        push(@unlink, $f);
        $runWB = 0 if $Instr{noRerun} && lc substr($f, -3) eq "odc" && -e $f;
      }
      elsif (/check\(\s*'(.*)'/)
      {
        $model = $1;
      }
      elsif (/compile\(([^\)]*)\)/)
      {
        $nChains = $1;
        $nChains =~ s/\s//g;
      }
      elsif (/set\(([^\)]+)\)/)
      {
        my $node = $1;
        $node =~ s/\[.*//;
        $node =~ s/\s+//g;
        $monitored{$node} = 1;
      }
      elsif (/coda\(([^,]*),([^\)]*)\)/)
      {
        my ($node, $file) = ($1, $2);
        $node =~ s/\s//g;
        $file =~ s/^\s+|\s+$//g; # lrtrim
        $file = substr($file, 1, -1);
        $codaFile{$node}{++$ncodaFiles{$node}} = $file;
      }
    }
  }


  # --- read the model to see if any indication was given as of nodes to take exp() or inv.logit()

  open(MODEL, $model) || die "Cannot read model from file $model\nAbort.\n";
  while (<MODEL>)
  {
    next unless /#\s*\-(exp|or|inv\.logit)/i;
    my ($found, $etc) = (lc $1, $');

    s/#.*//;
    s/\<\-/ /;
    s/\~/ /;
    /\S+/;

    $_ = $&;

    if ($found eq "exp" || $found eq "or")
    {
      $_ .= "->" . $' if $etc =~ /\s*\-\>/ && !$`;
      &ReadExp($_);
    }
    elsif ($found eq "inv.logit")
    {
      $ComputeInvLogit{$_} = 1;
    }

    $altname{$_} = $altname if defined $altname;
  }
  close MODEL;


  # --------------------------------------------------------------------------------------------

  # Do not run if script was unchanged, as compared to what is found in WinBUGS txt output file

  if ($runWB)
  {
    my $unchanged = &UnchangedScript($pgm);
    $runWB = 0 if $unchanged;
  }


  # ----------------------------------------------------------------------------
  # Submit WinBUGS script (if indicated)

  if ($runWB)
  {
    $nmodelsrun++;
    if ($nmodelsrun <= $Instr{skip})
    {
      print STDERR "\nSkipped: " . Win32::GetFullPathName($pgm) . " ...\n";
      next;
    }
    elsif ($Instr{WouldRun})
    {
      push(@wouldrun, Win32::GetFullPathName($pgm));
      next;
    }
  }
  else
  {
    print STDERR "Not re-run: " . Win32::GetFullPathName($pgm) . "\n";
    next;
  }

  # --- Delete hash tables from previous pgm re-submitted ---------------------------

  undef %_wbsplogcmd;
  undef %_wbsplog2edit;
  undef %_wbspfile2rm;
  undef %_wbsprename;


  # --- Change data files with regards to variables to drop ------------------------
  # (following -x user instructions in WriteWinBUGSScript)

  if (@vars2drop)
  {
    my @tmpscript = @script0;
    undef @script0;

    foreach (@tmpscript)
    {
      chomp;
      s/#.*//;
      next unless /\S/;

      if (/data\(\'(.*)\'\)/)
      {
        my $data = $1;
        my ($datapath, $droppedvars) = &CleanData($data, $Tmp{dir}, $Instr{prefix}, @vars2drop);
        next unless $datapath;

        push(@script0, "data('$datapath')");

        if ($datapath ne $data)
        {
          $_wbspfile2rm{$datapath} = 1;
          $droppedvars{$datapath}  = $droppedvars;
          $anydatachanged = 1;
          $srcdatafile{$datapath} = $data;
        }
      }
      else
      {
        push(@script0, $_);
      }
    }
  }


  # --- Re-write script --------------------------------------------------------

  my @script;

  foreach (@script0)
  {
    chomp;
    s/#.*//;

    if (/\s*(set|density|history)\((.*)\)/i && !$`)
    {
      next if &DoNotMonitor($2);
    }

    push(@script, $_);
  }

  @script = &WinBUGSScriptShortPathNames($Max{wbLPath}, $Max{codaLPath}, $Tmp{dir}, $Instr{prefix}, @script);

  # --- Copy tmp script in a file ---

  unlink $Tmp{script};

  open(TMP, ">$Tmp{script}") || die "Cannot write tmp script to file $Tmp{script}. Abort.\n";
  foreach (@script)
  {
    print TMP $_ . "\n";
  }
  close TMP;

  # remove output files if they already exist

  unlink(@unlink);


  # --- Run WinBUGS script ---

  &RunWinBUGSScript($Tmp{script}, $pgm, @NIter);

  my $runtime = &TimeHMS(time - $time0);


  # Write back original paths in ASCII WinBUGS log file and align stats

  my @wblogs = keys %_wbsplog2edit;

  foreach my $logf (@wblogs)
  {
    my (@log, @table);

    open(LOG, $logf) || die "Cannot read log file $logf. Abort.\n";
    while (<LOG>)
    {
      chomp;
      push(@log, $_);

      if (/\t/)
      {
        push(@table, $_);

        my $tmp = $';
        $tmp =~ /\S+/;
        my $node = $&;

        $tmp = $';
        next if $tmp =~ /mean/;

        $NodeStats{$node} = $tmp;
        my @tmp = split(" ", $tmp);
        my ($mean, $sd, $niter) = ($tmp[0], $tmp[1], $tmp[7]);

        $NodeStat{$node}{nblocks}++;
        $NodeStat{$node}{sum} += $niter * $mean;
        $NodeStat{$node}{sum2} += $niter * ($sd**2) + $niter * ($mean**2);
        $NodeStat{$node}{niter} += $niter;
        $NodeStat{$node}{no} ||= ++$nNodes;
      }
      else
      {
        $_ = $_wbsplogcmd{$_} if $_wbsplogcmd{$_}; # write long path name in log cmd if it was there originally
      }
    }
    close LOG;


    my $UsedClear;
    my @nodes = sort {$NodeStat{$a}{no} <=> $NodeStat{$b}{no}} keys %NodeStat;

    foreach my $node (@nodes)
    {
      if ($NodeStat{$node}{nblocks} > 1)
      {
        $UsedClear = 1;
        last;
      }
    }


    if ($UsedClear)
    {
      foreach my $node (@nodes)
      {
        $NodeStat{$node}{myxbar} = $NodeStat{$node}{sum} / $NodeStat{$node}{niter};
        $NodeStat{$node}{mysd} = sqrt(($NodeStat{$node}{sum2} - $NodeStat{$node}{niter}*($NodeStat{$node}{myxbar}**2)) / $NodeStat{$node}{niter});
      }

      push(@log, &CombinedNodeStats());
    }
    else
    {
      @log = &Paths2OriginalDataFiles(@log) if $anydatachanged;
      push(@table, &ComputeSomeNodesFct(@nodes)) if $ComputeNodeStat{exp} || $ComputeNodeStat{invLogit};
      push(@log, &AlignedStats(@table));
      # @log = &ReArranged(@log);
    }


    if (@noExp)
    {
      push(@log, "Could not provide exp() node statistics for following node(s):");

      foreach (@noExp)
      {
        push(@log, "\t" . $_);
      }

      push(@log, "", "");
    }

    push(@log, "Run time: $runtime");  # Report run time to log file
    push(@log, "", "# script:\t$pgm"); # Add the path of script file


    # Rewrite log file (either in the same place [overwrite] or in the right place)

    $_wbsprename{$logf} ||= $logf;

    open(LOG, ">$_wbsprename{$logf}") || die "Cannot overwrite log file $_wbsprename{$logf}. Abort.\n";
    foreach (@log)
    {
      chomp;
      print LOG $_ . "\n";
    }
    close LOG;

    unlink($logf) if $_wbsprename{$logf} ne $logf;
    delete $_wbsprename{$logf};
  }

  # Clean coda output files (if necessary)
  &CleanCodaFiles() if keys %codaFile;

  # -- Move WinBUGS output files from temporary to expected locations

  foreach (keys %_wbsprename)
  {
    rename($_, $_wbsprename{$_});
  }

  # -- Remove temporary copies of models, inits and data sets

  unlink keys %_wbspfile2rm;

  print STDERR $runtime . "\n\n";
}


if (@wouldrun)
{
  print STDERR "\n\nWould run:\n";
  foreach (@wouldrun)
  {
    print STDERR "  " . $_ . "\n";
  }
}







# --- remove tmp files ---


unlink $Tmp{script};



# ---- End of code ------------------------------------------------------------------------


sub AlignedBlock()
{
  my ($nsep, $header, @lines) = @_;
  my ($w0, $w1, $tmpw0, $tmpw1, $rest, $spaces,
      @header);

  # Values in columns are aligned through their decimal point,
  # except for first line ($header), which will be left-aligned.
  # (if no header is to be printed on top of table, call AlignedBlock with "" for $header)

  # Typical use:
  # ------------
  #
  # $header = "alpha\tbeta\tgamma\n-----\t----\t\-----";
  # $header .= "\n\t"; # if you want a blank line to appear between the table and its header
  # @table = ("1.42\t-10.2\t12", "100\t2101.20\t-32.2");
  # &AlignedBlock(5, $header, @table);
  #

  @header = split("\n", $header);

  foreach (@header)
  {
    s/\s*\t\s*/\t/g; # rm spaces around tabs
    s/\s*(.*)/\1/g; # ltrim
    s/\s+$//;       # rtrim
  }


  while ($lines[0] =~ /\t/)
  {
    undef $w0;
    undef $w1;

    foreach (@header)
    {
      /\t/;
      $tmpw0 = length($`);
      $w0 = $tmpw0 if $tmpw0 > $w0;
    }

    foreach (@lines)
    {
      /\t/;
      $tmpw0 = length($`);
      
      $rest = $';
      $rest = $` if $rest =~ /\t/;
      $rest = $` if $rest =~ /\./;
      $tmpw1 = length($rest);

      $w0 = $tmpw0 if $tmpw0 > $w0;
      $w1 = $tmpw1 if $tmpw1 > $w1;
    }

    foreach (@lines)
    {
      /\t/;
      $spaces = length($`);
      $rest = $';
      $rest = $` if $rest =~ /\t/;
      $rest = $` if $rest =~ /\./;
      $spaces += length($rest);
      $spaces = " " x ($w0 + $w1 - $spaces + $nsep);
      s/\t/$spaces/;
    }

    foreach (@header)
    {
      /\t/;
      $spaces = " " x ($w0 - length($`) + $nsep);
      s/\t/$spaces/;
    }
  }

  (@header, @lines);
}


sub AlignedStats()
{
  my (@table) = @_;
  my ($t);

  # IMP: needs AlignedBlock.txt to be require'd

  foreach (@table)
  {
    s/[^\t]*\t//; # remove everything 'til 1st tab
  }

  @table = &AlignedBlock(2, @table);
  foreach $t (@table)
  {
    $t = "\t$t";
  }

  @table;
} # end of AlignedStats


sub CleanCodaFiles()
{
  my @nodes = keys %codaFile;
  my @ch = (1..$nChains);
  
  foreach my $node (@nodes)
  {
    my $nfiles = $ncodaFiles{$node};
    next if $nfiles == 1;
    
    $codaFile{$node}{1} =~ /(.*)\-1/;
    my $head = $1;
    
    
    if ($node eq "*")
    {
      my ($nnodes, %index, %niter, %nodeno);
      
      # Read index files

      foreach my $fno (1..$nfiles)
      {
        my @nm;

        my $IndexFile = $codaFile{$node}{$fno} . "Index.txt";
        open(INDEX, $IndexFile);
        while (<INDEX>)
        {
          next unless /\S/;
          chomp;
          my ($node, $i0, $i1) = split;
          my $niter = $i1 - $i0 + 1;
          push(@nm, $node, $niter);
          $niter{$node} += $niter;
          $nodeno{$node} ||= ++$nnodes;
        }
        close INDEX;

        $index{$fno} = join(" ", @nm);
        unlink $IndexFile;
      }
      
      # Write new index file

      my @nodes = sort {$nodeno{$a} <=> $nodeno{$b}} keys %nodeno;

      my $IndexFile = $head . "Index.txt";
      my ($i0, $i1);
      $i1 = 0;
      open(INDEX, ">$IndexFile");
      foreach my $node (@nodes)
      {
        $i0 = $i1 + 1;
        $i1 += $niter{$node};
        print INDEX join(" ", $node, $i0, $i1) . "\n";
      }
      close INDEX;
      
      # Read coda files
    
      foreach my $ch (@ch)
      {
        my %coda;
        
        foreach my $fno (1..$nfiles)
        {
          my $file = $codaFile{"*"}{$fno} . "$ch.txt";
          
          my @nm = split(" ", $index{$fno});
          my ($k, $node, $niter) = (0, splice(@nm, 0, 2));

          open(CODA, $file);
          while (<CODA>)
          {
            $coda{$node} .= $_;
            $k++;
            ($k, $node, $niter) = (0, splice(@nm, 0, 2)) if $k == $niter;
          }
          close CODA;
          unlink $file;
        }
        
        # Write new coda file
        
        my $codaFile = $head . $ch . ".txt";
        open(CODA, ">$codaFile");
        foreach my $node (@nodes)
        {
          print CODA $coda{$node};
        }
        close CODA;
      }
    }
    else
    {
      # Read Index files for this node, remove them and write a new one
    
      my $niter;
    
      foreach my $fno (1..$nfiles)
      {
        my $IndexFile = $codaFile{$node}{$fno} . "Index.txt";
        open(INDEX, $IndexFile);
        my $index = <INDEX>;
        close INDEX;
        chomp $index;
        my @tmp = split(" ", $index);
        my $codaNIter = pop @tmp;
        $niter += $codaNIter;
        unlink $IndexFile;
      }
    
      my $newIndex = $head . "Index.txt";
      open(INDEX, ">$newIndex");
      print INDEX join(" ", $node, 1, $niter) . "\n";
      close INDEX;
    
      # Rename first coda file and append the others

      foreach my $ch (@ch)
      {
        my $file = $codaFile{$node}{1} . "$ch.txt";
        my $new  = $head . "$ch.txt";
        rename($file, $new);
      
        open(NEW, ">>$new");
      
        foreach my $fno (2..$nfiles)
        {
          my $file = $codaFile{$node}{$fno} . "$ch.txt";

          open(TMP, $file);
          while (<TMP>)
          {
            print NEW;
          }
          close TMP;
          unlink $file;
        }
      
        close NEW;
      }
    }
  }
} # end of CleanCodaFiles


sub CleanData()
{
  my ($file, $tmpdir, $prefx, @vars2drop) = @_;
  my ($anyvarin, $new, $var, @data, @new, %droppedvar, %var2drop);


  open(DATA, $file);
  while (<DATA>)
  {
    s/#.*//;
    next unless /\S/;
    chomp;
    push(@data, $_);
  }
  close DATA;


  my $islist = $data[0] =~ /list\(/ ? 1 : 0;


  foreach (@vars2drop)
  {
    $var2drop{$_} = 1;
  }


  if ($islist)
  {
    my $data = join("\n", @data);
    $data =~ /list\(/;
    ($new, $data) = ($&, $');

    $data =~ s/\s*=\s*/ = /g;
    $data =~ s/,/, /g;

    while ($data =~ /(\S+)\s*=\s*/)
    {
      ($var, $data) = ($1, $');
      $new .= $`;

      $data =~ /[,\(\)]/;
      my ($left, $match, $right) = ($`, $&, $');
      $left =~ s/\s//g;

      if ($match eq "(")
      {
        if ($left eq "c")
        {
          $data =~ /\)/;
          $data = $';

          if ($var2drop{$var})
          {
            $droppedvar{$var} = 1;
          }
          else
          {
            $anyvarin = 1;
            $new .= "$var = " . $` . ")";
          }
        }
        else
        {
          # $left eq "structure"

          $data =~ /\.Dim\s*=[^\)]*\)[^\)]*\)/;
          ($left, $data) = ($` . $&, $');

          if ($var2drop{$var})
          {
            $droppedvar{$var} = 1;
          }
          else
          {
            $anyvarin = 1;
            $new .= "$var = $left";
          }
        }
      }
      elsif ($match eq ",")
      {
        $data = $match . $right;

        if ($var2drop{$var})
        {
          $droppedvar{$var} = 1;
        }
        else
        {
          $anyvarin = 1;
          $new .= "$var = $left" . $match;
        }
      }
      else
      {
        # $match eq ")"

        $data = $right;

        if ($var2drop{$var})
        {
          $droppedvar{$var} = 1;
        }
        else
        {
          $anyvarin = 1;
          $new .= "$var = $left" . $match;
        }
      }
    }

    $new .= $data;

    $new =~ s/ +/ /g;
    $new =~ s/ \n/\n/g;
    $new =~ s/,\s*,/,/g while $new =~ /,\s*,/;
    $new =~ s/\(\s*\,\s*/\( /g;
    $new =~ s/\s*,\s*\)/\)/g;
  }
  else
  {
    # rectangular data file

    my ($brackets, $lov, $lov0, @keep, @lov);

    $lov = shift @data;
    $lov0 = $lov;
    $lov =~ s/\[[^\]]*\]//g;
    @lov = split(" ", $lov);

    my $col = 0;

    foreach (@lov)
    {
      if ($var2drop{$lov[$col]})
      {
        $droppedvar{$lov[$col]} = 1;
      }
      else
      {
        push(@keep, $col);
        $anyvarin = 1;
      }

      $col++;
    }

    foreach (@data)
    {
      my @tmp = split;
      $new = join(" ", @tmp[@keep]);
      push(@new, $new);
    }

    # add top line with variable names

    undef $new;
    while ($lov0 =~ /\[/)
    {
      $new .= $` . $&;
      $lov0 = $';
      if ($lov0 =~ /\]/)
      {
        ($brackets, $lov0) = ($`, $');
        $brackets =~ s/\s+//g;
        $new .= $brackets . "]";
      }
    }

    $new .= $lov0;
    @lov = split(" ", $new);
    $new = join(" ", @lov[@keep]);
    unshift(@new, $new);
  }


  my @droppedvars = sort {lc $a cmp lc $b} keys %droppedvar;


  if ($anyvarin && @droppedvars)
  {
    my $newfile = "$tmpdir/$prefx";
    $newfile =~ s{\\+}{/}g;
    $newfile = &FirstAvailableFilename($newfile, "txt");
    $newfile = Win32::GetFullPathName($newfile);
    $newfile =~ s{\\+}{/}g;

    open(NEW, ">$newfile");

    if ($islist)
    {
      chomp $new;
      print NEW $new . "\n";
    }
    else
    {
      foreach (@new)
      {
        print NEW $_ . "\n";
      }
    }

    close NEW;

    my $droppedvars = join(" ", @droppedvars);

    ($newfile, $droppedvars);
  }
  elsif ($anyvarin)
  {
    $file;
  }
  else
  {
    "";
  }
} # end of CleanData


sub CombinedNodeStats()
{
  my @log;
  my %lmargin = (node => 2, myxbar => 6, mysd => 2, niter => 2);
  my @statsDim = ("myxbar", "mysd");
  my (%l, %lnode);
  my $lnode = 0;
  
  my @nodes = sort {lc $a cmp lc $b} keys %NodeStat;
  
  # Compute lengths of integer and fractional parts of node means and sds in order to align them (around the dot/period)
  
    # initialize them
    foreach my $dim (@statsDim)
    {
      ($l{$dim}{l}, $l{$dim}{r}) = (0, 0);
    }
    
  
  foreach my $node (@nodes)
  {
    my $tmp = length($node);
    $lnode = $tmp if $tmp > $lnode;
    
    foreach my $dim (@statsDim)
    {
      my ($l, $r);
      
      if ($NodeStat{$node}{$dim} =~ /\./)
      {
        ($l, $r) = ($`, $');
      }
      else
      {
        ($l, $r) = ($NodeStat{$node}{$dim}, "");
      }
      
      ($l, $r) = (length($l), length($r));
      
      # round-off stat to the expected maximum number of digits
      if ($r > $Instr{CombinedNodeStatsNDigits})
      {
        my $stat = $NodeStat{$node}{$dim};
        $stat =~ /\.\d{$Instr{CombinedNodeStatsNDigits}}/;
        my ($short, $extra) = ($` . $&, $');
        $extra = $& if $extra =~ /\S/;
        
        if ($extra ne "e")
        {
          my $sign = $stat < 0 ? -1 : 1;
          $short += $sign * (10**-$Instr{CombinedNodeStatsNDigits}) if $extra >= 5;
          $NodeStat{$node}{$dim} = $short;
        }

        $r = $Instr{CombinedNodeStatsNDigits};
      }
      
      $l{$dim}{l} = $l if $l > $l{$dim}{l};
      $l{$dim}{r} = $r if $r > $l{$dim}{r};
      
      ($lnode{$node}{$dim}{l}, $lnode{$node}{$dim}{r}) = ($l, $r);
    }
  }
  
  
  my $title = "Combined node statistics";
  push(@log, "", "", $title, "-" x length($title), "");
  my @stats;

  
  foreach my $node (@nodes)
  {
    my $log = " " x $lmargin{node} . $node;
    my $l = $lnode - length($node);
    $log .= " " x $l;
    
    foreach my $dim (@statsDim)
    {
      $log .= " " x $lmargin{$dim};
      my $l = $l{$dim}{l} - $lnode{$node}{$dim}{l};
      $log .= " " x $l;
      $log .= $NodeStat{$node}{$dim};

      $l = $l{$dim}{r} - $lnode{$node}{$dim}{r};
      $log .= " " x $l;
    }
    
    $log .= " " x $lmargin{niter} . $NodeStat{$node}{niter};
    
    push(@stats, $log);
  }
  

  $title = " " x $lmargin{node} . "node";
  my $l = $lnode + $lmargin{myxbar} - 4;
  $title .= " " x $l . "mean";
  $l = $l{myxbar}{l} + 1 + $l{myxbar}{r} + $lmargin{mysd} - 4;
  $title .= " " x $l . "sd";
  $l =  $l{mysd}{l} + 1 + $l{mysd}{r} + $lmargin{niter} - 2;
  $title .= " " x $l . "#iter";
  
  push(@log, $title, "", @stats);
  
  my @fcts;
  push(@fcts, "exp") if $ComputeNodeStat{exp};
  push(@fcts, "inv.logit") if $ComputeNodeStat{invLogit};
  
  if (@fcts)
  {
    my $fcts = join("/", @fcts);
    push(@log, "", "It is not possible to report $fcts for the nodes for which it was requested as the memory-clear option was used when running WinBUGS. Sorry.");
  }
  
  (@log, "", "");
} # end of CombinedNodeStats


sub ComputeSomeNodesFct()
{
  my (@nodes) = @_;
  my ($lineno,
      @exptable,
      %expnodeno, %expfactor, %lineno, %mathfct);


  if ($ComputeNodeStat{exp} || $ComputeNodeStat{invLogit})
  {
    foreach my $node (@nodes)
    {
      my ($dim, @parms);
      my @nodestat = split(" ", $NodeStats{$node});

      ($node, $dim) = ($`, $& . $') if $node =~ /\[/;
      next unless $ComputeExp{$node} || $ComputeInvLogit{$node};
      $lineno++;

      my $mathfct = $ComputeExp{$node} ? "exp" : "inv.logit";

      foreach my $parm (keys %node)
      {
        push(@parms, $parm) if $node{$parm} eq $node;
      }


      foreach my $parm (@parms)
      {
        my ($obj, @exp);

        if ($parm =~ /\*/)
        {
          $obj = $mathfct . "(" . $parm . $dim . ")";
        }
        else
        {
          $obj = $parm;
          $obj =~ s{(.*)(/?)}{$1$dim$2};
          $obj = $mathfct . "(" . $obj . ")";
        }


        if ($altname{$parm})
        {
          @exp = ("$altname{$parm}$dim");
        }
        else
        {
          @exp = ($obj);
          undef $obj;
        }


        my $col = 1;

        foreach my $nodestat (@nodestat)
        {
          if ($Col2Fct{$col})
          {
            my $x = /e/i ? $` : $_;
            my $ndigits = $x =~ /\./ ? length($') : 0;

            if ($mathfct eq "exp")
            {
              $_ = exp($nodestat * $factor{$parm});
            }
            else
            {
              # inverse logit

              $_ = 1/(1+exp(-$nodestat));
            }

            if ($_ < 1)
            {
              # ensures that we won't see ORs like 0.00 for or=0.000364, but 3.65e-3 instead

              $_ = sprintf("%e", $_) if $_ < 1;
              my $fmt = /e/i ? "e" : "f";
              $ndigits = $Min{nDigitsInScientific} if $fmt eq "e" && $ndigits < $Min{nDigitsInScientific};
              $fmt = "%.$ndigits$fmt";
              $_ = sprintf($fmt, $_);
              s/(e[\+\-])0+([1-9])/\1\2/i;
              s/e\+0+//i;
            }
          }
          elsif (!$Col2Keep4Fct{$col})
          {
            $_ = $Instr{undefFct};
          }
          else
          {
            $_ = $nodestat;
          }

          # ensure that we do not report numbers like 9.9e-1/2/3, but rather 0.99/0.099/0.0099, which is more natural and seems a rule in nodes reported by WinBUGS anyhow!

          if (/e\-([123])/i && !$')
          {
            my $exp;
            ($_, $exp) = ($`, $1);
            my $negative = substr($_, 0, 1) eq "-" ? 1 : 0;
            s/\.//;
            $_ = "-" x $negative . "0." . "0" x ($exp-1) . $_;
          }
          elsif (/\./ && length($`) > 5)
          {
            $_ = sprintf("%.$Max{expNDigits}e", $_);
            s/e\+0+/e\+/;
          }
          else
          {
            s/(\.\d{0,$Max{expNDigits}})\d*/\1/;
          }

          push(@exp, $_);
          $col++;
        }

        push(@exp, $obj) if defined $obj;

        $_ = join("\t", "", @exp);

        $mathfct{$_}   = $mathfct;
        $expnodeno{$_} = $NodeStat{$node}{no};
        $expfactor{$_} = $factor{$parm};
        $lineno{$_}    = $lineno;

        push(@exptable, $_);
      }
    }

    my ($s, $what);
    $s = "s" if $#exptable > 0;
    $what = "odds ratio$s" if $ComputeNodeStat{exp};
    if ($ComputeNodeStat{invLogit})
    {
      $what .= " and " if $what;
      $what .= "inv.logit$s";
    }

    if (@exptable)
    {
      unshift(@exptable, "", "/$what/", "");

      @exptable = sort {$mathfct{$a} cmp $mathfct{$b} || $expnodeno{$a} <=> $expnodeno{$b} || $expfactor{$a} <=> $expfactor{$b} || $lineno{$a} <=> $lineno{$b}} @exptable;

      push(@exptable, "");
    }
  }

  @exptable;
} # end of ComputeSomeNodesFct


sub DoNotMonitor()
{
  my ($var) = @_;
  my $monitor = $DoNotMonitor{$var} ? 0 : 1;

  if ($monitor)
  {
    foreach (keys %DoNotMonitorIfVarnameStartsWith)
    {
      my $l = length;
      if (substr($var, 0, $l) eq $_)
      {
        $monitor = 0;
        last;
      }
    }
  }

  1 - $monitor;
} # end of DoNotMonitor


sub FileExtension()
{
  my ($filename) = @_;
  my ($ext);

  ($filename) = reverse Win32::GetFullPathName($filename);
  $ext = $' if $filename =~ /.*\./;
  lc $ext;
} # end of FileExtension


sub FirstAvailableCODAFilenames()
{
  my ($codaroot, $nchains) = @_;
  my ($k, $foundsome, @ch, @res);

  @ch = (1..$nchains);

  while ()
  {
    @res = ("$codaroot$k", "$codaroot${k}Index.txt");
 
    if (-e $res[1])
    {
      $k++;
      next;
    }

    $foundsome = 0;
    foreach (@ch)
    {
      push(@res, "$codaroot$k$_.txt");
      if (-e $res[$#res])
      {
        $foundsome = 1;
        last;
      }
    }

    last unless $foundsome;
    $k++;
  }

  @res;
} # end of FirstAvailableCODAFilenames


sub FirstAvailableFilename()
{
  my ($path, $ext, $useletters) = @_;
  my ($k, $ksuffx, $newfile);

  # c:/users/patrick.belisle/My Documents/Home/bin/PerlFcts/Strings.txt must also be require'd when $useletters=1 option is used

  $ext = ".$ext" if $ext;
  $newfile = "$path$ext";

  while (-e $newfile)
  {
    $k++;
    $ksuffx = $useletters ? &MyChr($k) : $k;
    $newfile = "$path$ksuffx$ext";
  }

  $newfile;
} # end of FirstAvailableFilename


sub MyChr()
{
  my ($i) = @_;
  my $j;

  # Turns 1 into a, 2 into b, ..., 26 into z, 27 into aa, 28 into ab, ..., 52 into az, etc.
  # useful for file names suffixes

  if ($i <= 26)
  {
    chr(96 + $i);
  }
  else
  {
    $j = int (($i-1)/26);
    &MyChr($j) . chr(97 + ($i-1)%26);
  }
} # end of MyChr


sub Paths2OriginalDataFiles()
{
  my (@log) = @_;
  my @newlog;

  foreach (@log)
  {
    if (/data\((.*)\)/)
    {
      my $data = $1;

      if ($srcdatafile{$data})
      {
        my $tmp = $droppedvars{$data} =~ /\s/ ? "s were" : " was";
        push(@newlog, "data(" . $srcdatafile{$data} . ")");
        push(@newlog, "# from which the following variable$tmp dropped:", "# " . $droppedvars{$data});
        next;
      }
    }

    push(@newlog, $_);
  }

  @newlog;
} # end of Paths2OriginalDataFiles


sub PrintSection()
{
  my ($title, $sepchar, @txt) = @_;
  my $l;

  foreach (@txt)
  {
    s/\s+$//; # rtim
    my $tmpl = length;
    $l = $tmpl if $tmpl > $l;
  }
  $l += 5;

  unshift(@txt, $sepchar x $l, ucfirst $title, "-" x length($title), "");
  push(@txt, $sepchar x $l, "");
  
  foreach (@txt)
  {
    print STDERR $_ . "\n";
  }
} # end of PrintSection


sub Read()
{
  my ($file) = @_;
  my ($altscript, $ext, $isscript, $run);

  # global variables: @InputFiles, @OutputFiles

  open(TMP, $file) || die "Cannot read file $file\nSorry\n";
  while (<TMP>)
  {
    if (/(check|data)\s*\(\s*'([^']*)'\s*\)/)
    {
      push(@InputFiles, $2);
      $isscript = 1 if $1 eq "check";
    }
    elsif (/inits\s*\(\s*\d+\s*,\s*'([^']*)'\s*\)/)
    {
      push(@InputFiles, $1);
    }
    elsif (/save\s*\(\s*'([^']*)'\s*\)/)
    {
      my $outfile = $1;
      my $tmp = $outfile;

      $tmp = $' if $tmp =~ /.*[\\\/]/;

      if ($tmp =~ /.*\./)
      {
        $ext = lc $';
        $run = 1 unless $ext eq "odc" || $ext eq "txt";
      }
      else
      {
        $outfile .= ".odc";
      }

      push(@OutputFiles, $outfile);
    }
    elsif (/coda\s*\(.*'([^']*)'\s*\)/)
    {
      my $outfile = $1;
      push(@OutputFiles, "${outfile}1.txt", "${outfile}Index.txt");
    }
    elsif (/# script\:\t/)
    {
      $altscript = $';
      chomp $altscript;

      if (-f $altscript)
      {
        $isscript = 1;
        $ext = lc $' if $altscript =~ /.*\./;
        $run = 1 if $ext eq "txt";
      }
    }
  }
  close TMP;

  ($isscript, $run, $altscript);
} # end of Read


sub ReadExp()
{
  my ($tmp) = @_;

  # Global variables:
  # -----------------
  # @noExp
  # %altname
  # %ComputeExp
  # %factor
  # %monitored
  # %node


  $tmp =~ s{\s*\-\s*\>\s*}{->}g;
  $tmp =~ s{\s*([\/\*])\s*}{\1}g;

  my @tmp = split(" ", $tmp);

  foreach (@tmp)
  {
    my ($altname, $f, $node, $parm);
    ($_, $altname) = ($`, $') if /\-\>/;

    if (/\//)
    {
      ($node, $parm, $f) = ($`, $_, 1/$');
      push(@noExp, $parm) unless $monitored{$node};
    }
    elsif (/\*/)
    {
      if ($monitored{$`} && $monitored{$'})
      {
        push(@noExp, $_);
      }
      elsif ($monitored{$`})
      {
        ($node, $parm, $f) = ($`, $' . "*" . $`, $');
      }
      elsif ($monitored{$'})
      {
        ($node, $parm, $f) = ($', $_, $`);
      }
      else
      {
        push(@noExp, $_);
      }
    }
    else
    {
      ($node, $parm, $f) = ($_, $_, 1);
      push(@noExp, $parm) unless $monitored{$node};
    }


    $ComputeExp{$node} = 1;
    ($factor{$parm}, $node{$parm}) = ($f, $node);

    $altname{$parm} = $altname if defined $altname;
  }
} # end of ReadExp


sub RunWinBUGSScript()
{
  my ($script) = @_;

  # IMPORTANT: $My{WinBUGS}{path} must be defined, e.g., through require "c:/users/patrick.belisle/My Documents/Home/bin/paths/WinBUGS.txt";

  $script = Win32::GetLongPathName($script);
  $script =~ s{\\+}{/}g; 

  my $cmd = "\"$My{WinBUGS}{path}\" /PAR \"$script\"";
  $cmd =~ s/(.*\S)\s+(\S+)/\1 "\2"/ unless substr($cmd, -1) eq "\"";
  system($cmd) && die "Could not run: $cmd\n";
} # end of RunWinBUGSScript


sub TimeHMS()
{
  my ($t) = @_;
  my ($mm, $ss);

  if ($t < 60)
  {
    "$t seconds";
  }
  else
  {
    $ss = $t%60;
    $t -= $ss;
    $ss = "0$ss" if $ss < 10;

    $t /= 60;
    if ($t < 60)
    {
      "$t:$ss min";
    }
    else
    {
      $mm = $t%60;
      $t -= $mm;
      $mm = "0$mm" if $mm < 10;
      $t /= 60;
      "$t:$mm:$ss h";
    }
  }
} # end of TimeHMS


sub Touch()
{
  my (@files) = @_;
  my ($fname);

  foreach $fname (@files)
  {
    open(TOUCH, ">$fname");
    close TOUCH;
  }
} # end of Touch


sub TrueDate()
{
  my ($francais) = @_;

  my ($date, $dd, $mm, $yy,
      %mm);

  %mm = ("Jan" => "janvier", "Feb" => "février",  "Mar" => "mars", 
         "Apr" => "avril",   "May" => "mai",      "Jun" => "juin",
         "Jul" => "juillet", "Aug" => "août",     "Sep" => "septembre", 
         "Oct" => "octobre", "Nov" => "novembre", "Dec" => "décembre");

  $date = localtime;
  $date =~ /\w+\s+(\w+)\s+(\d+)\s+\S+\s+(\d+)/;
  ($mm, $dd, $yy) = ($1, $2, $3);

  $mm = $mm{$mm} if $francais;

  "$dd $mm{$mm} $yy";
}


sub UnchangedScript()
{
  my ($script) = @_;
  my ($logfile, $logfileAge,  %age, %srcFile);

  my $unchanged = 1;

  open(SCRIPT, $script) || die "Cannot read script $script\nSorry\n";
  while (<SCRIPT>)
  {
    s/#.*//;
    next unless /(data|inits|save|check)\((['"])([^'"]+)$2/;
    my ($cmd, $srcfile) = ($1, $3);

    if ($cmd eq "save")
    {
      $logfile = $srcfile if $srcfile =~ /\.txt/i && !$';
    }
    else
    {
      $srcFile{$srcfile} = 1;
    }

    $logfile = $1 . $2 if /save\((.*)(\.txt)/;
  }
  close SCRIPT;


  if ($logfile && -e $logfile)
  {
    $logfileAge = -M _;
    my $scriptAge = -M $script;

    if ($scriptAge < $logfileAge)
    {
      $unchanged = 0;
    }
    else
    {
      # compare src files' age to logfile's age
      
      foreach (keys %srcFile)
      {
        my $age = -M;
        if ($age < $logfileAge)
        {
          $unchanged = 0;
          last;
        }
      }
    }
  }
  else
  {
    $unchanged = 0;
  }


  $unchanged;
} # end of UnchangedScript


sub WinBUGSScriptShortPathNames()
{
  my ($maxlpath, $codamaxlpath, $tmpdir, $tmpprefx, @wbcmds) = @_;
  my ($dir, $filename, $action, $fcmd, $fileext, $new, $msg,
      $cmd0, $cmd1, $origpath, $finallocation,
      $logcmd0, $logcmd1, $logcmd, $log2edit, $nch,
      @new,
      %maxlpath);

  # Change long file names in WinBUGS scripts commands to short path names (if necessary)

  # IMPORTANT:
  # **********
  #
  # - requires that  "use Win32;" and use "File::Copy;" were declared beforehand
  # - needs that &FirstAvailableCODAFilenames is loaded (from bin\PerlFcts\winbugs.txt)
  # - needs that &FileExtension, &FirstAvailableFilename, and &Touch are also loaded (all defined in bin\PerlFcts\files.txt)
  #
  # - creates global hash tables [listed below], to be used once the WinBUGS script is run to either rename output files or remove tmp copies of input files
  #   [_wbsprename, _wbspfile2rm, _wbsplog2edit, _wbsplogcmd]

  # Results: paths will remain untouched if short enough, otherwise they will be shortened through GetShortPathName;
  #          if name is still too long, file will be saved in $tmpdir instead ($ENV{'TMP'} by default, see comments below)
  #
  # In any case where a path is not truncable to desirable length, an error msg will be sent to STDERR and program will abort


  # ARGS:
  # -----
  #
  # maxlpath:           max path length correctly interpreted by WinBUGS (119, as of sept 2005)
  #                     -> MUST BE SPECIFIED
  #
  # codamaxlpath:       max path length correctly interpreted by WinBUGS in a coda() command line (114, as of sept 2005)
  #                     -> MUST BE SPECIFIED
  #
  # tmpdir:             where output files should be saved, shall their intended location path be too long (even when shortened with GetShortPathName)
  #                     -> CAN BE LEFT EMPTY (default: $ENV{'TMP'})
  #
  # tmpprefx:           the prefix to be used for tmp file names saved in tmpdir when original file name is still too long
  #
  # wbcmds:             a series of WinBUGS cmds to be checked relatively to the lengths of the file paths therein
  #                     [e.g., save('c:/users/patrick.belisle/My Documents/Home/tmp/tmp.odc') --- inits(1, 'c:/users/patrick.belisle/My Documents/Home/tmp/inits.txt') etc]
  #

  ($maxlpath0, $maxlpath{"coda"}) = ($maxlpath, $codamaxlpath);


  $tmpdir = Win32::GetShortPathName($ENV{'TMP'}) unless $tmpdir;
  $tmpdir =~ s{\\+}{/}g;
  chop $tmpdir if substr($tmpdir, -1) eq "/";

  foreach (@wbcmds)
  {
    $fcmd = $_;

    if (/\s*compile\s*\(\s*(\d+)\s*\)/ && !$`)
    {
      $nch = $1;
      next;
    }

    s{\\+}{/}g;
    next unless /'(.*)'/;

    ($cmd0, $origpath, $cmd1) = ($`, $1, $');
    $finallocation = $origpath;
    $action = lc $1 if $cmd0 =~ /\s*(\S+)\s*\(/;
    $maxlpath = $maxlpath{$action} || $maxlpath0;

    $fileext = &FileExtension($origpath);

    if (!$fileext && $action eq "save")
    {
      $fileext = "odc";
      $finallocation .= ".$fileext";
    }

    $log2edit = ($action eq "save" && $fileext eq "txt") ? 1 : 0;


    if (length($origpath) > $maxlpath)
    {
      # Try same location, short name

      ($dir, $filename) = Win32::GetFullPathName($origpath);
      $dir = Win32::GetShortPathName($dir);
      $dir =~ s{\\}{/}g;
      $new = $dir . $filename;

      if (length($new) > $maxlpath)
      {
        # Try same name, tmpdir (short)

        $new = "$tmpdir/$filename";

        if ((length($new) > $maxlpath) || -e $new)
        {
          # Use tmpdir (short), with arbitrary name

          if ($action eq "coda")
          {
            ($new, @new) = &FirstAvailableCODAFilenames("$tmpdir/$tmpprefx", $nch);
          }
          else
          {
            $new = &FirstAvailableFilename("$tmpdir/$tmpprefx", $fileext);          
          }

          if (length($new) > $maxlpath)
          {
            ($new) = reverse Win32::GetFullPathName($0);
            $new = $1 if $new =~ /(.*)\./;
            $new = "$ENV{'HOMEDRIVE'}/_$new";
            $new =~ s{[\\/]+}{/}g;

            if ($action eq "coda")
            {
              ($new, @new) = &FirstAvailableCODAFilenames($new, $nch);
            }
            else
            {
              $new = &FirstAvailableFilename($new, $fileext);          
            }
          }


          # Touch the new file(s) (to make it/them exist, thus avoiding its/their use for next file(s))

          if ($action eq "coda")
          {
            &Touch(@new);
            die "Path too long in WinBUGS script cmd ($maxlpath characters allowed):\n$fcmd\n" unless -w $new[0];
          }
          else
          {
            &Touch($new);
            die "Path too long in WinBUGS script cmd ($maxlpath characters allowed):\n$fcmd\n" unless -w $new;
          }
        }

        if ($action eq "save")
        {
          $_wbsprename{$new} = $finallocation;
        }
        elsif ($action eq "coda")
        {
          @new = ("Index", 1..$nch);
          foreach (@new)
          {
            $_wbsprename{"$new$_.txt"} = "$origpath$_.txt";
          }
        }
        elsif ($action eq "inits" || $action eq "data" || $action eq "check")
        {
          copy($origpath, $new);
          $_wbspfile2rm{$new} = 1;
        }
        else
        {
          print STDERR "$action unknow by $0 on line $lineno ($_)\n";
        }
      }

      $_wbsplog2edit{$new} = 1 if $log2edit;

      $_ = "$cmd0'$new'$cmd1";


      ($logcmd0, $logcmd1) = ($cmd0, $cmd1);
      $logcmd0 =~ s/ //g;
      $logcmd1 =~ s/ //g;
      chomp $logcmd1;
      $logcmd               = $logcmd0 . $new      . $logcmd1;
      $_wbsplogcmd{$logcmd} = $logcmd0 . $origpath . $logcmd1;
    }
    else
    {
       $_wbsplog2edit{$origpath} = 1 if $log2edit;
    }
  }


  @wbcmds;
} # end of WinBUGSScriptShortPathNames
