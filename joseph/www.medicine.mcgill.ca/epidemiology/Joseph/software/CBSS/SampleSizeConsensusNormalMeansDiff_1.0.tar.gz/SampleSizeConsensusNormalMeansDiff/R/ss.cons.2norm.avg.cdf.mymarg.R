ss.cons.2norm.avg.cdf.mymarg <-
function(cdf.points, accepted.cdf.diff, prior1, prior2, clinical.prior,
                                                 n2.n1.ratio=1, n.start=1000, n.max=100000, sim.size=50000,
                                                 max.cons.steps.same.dir=3)
{
  # prior1 and prior2 must be lists with dimensions mu0, n0, prec.shape and prec.rate
  tmp <- .ss.cons.2norm.check.list(prior1, "prior1")
  tmp <- .ss.cons.2norm.check.list(prior2, "prior2")
  tmp <- .ss.cons.2norm.check.list(clinical.prior, "clinical.prior")

  tmp <- .ss.cons.2norm.known.sds(prior1, prior2)
  
  
  if (all(tmp$known) & length(cdf.points) == 1)
  {
    out <- .ss.cons.2norm.cdf.known.sds(tmp, cdf.points, accepted.cdf.diff, clinical.prior=clinical.prior, n2.n1.ratio=n2.n1.ratio,
              n.start=n.start, n.max=n.max)
  
    out <- c(out, list(cdf.points=cdf.points, accepted.cdf.diff=accepted.cdf.diff, 
                       prior1=prior1, prior2=prior2, clinical.prior=clinical.prior, 
                       n2.n1.ratio=n2.n1.ratio, n.start=n.start, n.max=n.max, exact.results=T))
  }
  else
  {
    out <- .ss.cons.2norm.cdf(cdf.points, accepted.cdf.diff, prior1, prior2,
                                                                sim.size, n.start, n.max, clinical.prior=clinical.prior, n2.n1.ratio=n2.n1.ratio,
                                                                mcs=max.cons.steps.same.dir)

    out <- c(out, list(cdf.points=cdf.points, accepted.cdf.diff=accepted.cdf.diff,
                       prior1=prior1, prior2=prior2, clinical.prior=clinical.prior,
                       n2.n1.ratio=n2.n1.ratio, n.start=n.start, n.max=n.max, sim.size=sim.size,
                       max.cons.steps.same.dir=max.cons.steps.same.dir, exact.results=F))
  }
  
  return(out)
}
