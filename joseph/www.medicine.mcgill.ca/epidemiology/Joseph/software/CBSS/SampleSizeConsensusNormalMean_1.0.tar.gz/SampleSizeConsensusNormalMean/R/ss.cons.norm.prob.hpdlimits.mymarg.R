ss.cons.norm.prob.hpdlimits.mymarg <-
function(accepted.diff, prior1, prior2, clinical.prior, 
                                                         prob=0.5, level=0.95, n.start=1000, n.max=100000, sim.size=50000,
                                                         max.cons.steps.same.dir=3)
{  
  # prior1 and prior2 must be lists with dimensions mu0, n0, prec.shape and prec.rate
  tmp <- .ss.cons.norm.check.list(prior1, "prior1")
  tmp <- .ss.cons.norm.check.list(prior2, "prior2")
  tmp <- .ss.cons.norm.check.list(clinical.prior, "clinical.prior")

  out <- .ss.cons.norm.hpdlimits(accepted.diff, prior1, prior2,
                                           level, sim.size, n.start, n.max, max.cons.steps.same.dir,
                                           clinical.prior=clinical.prior,
                                           prob=prob, increasing.outcome.with.n=T)
    
  out <- c(out, list(accepted.diff=accepted.diff, prior1=prior1, prior2=prior2, clinical.prior=clinical.prior,
                     prob=prob, level=level, n.start=n.start, n.max=n.max, sim.size=sim.size,
                     max.cons.steps.same.dir=max.cons.steps.same.dir, exact.results=F))
  return(out)
}
