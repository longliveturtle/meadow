ss.cons.binom.prob.hpdlimits.mymarg <-
function(accepted.pdiff, prior1, prior2, clinical.prior, prob=0.5, 
                                                          level=0.95, n.start=1000, n.max=1e7)
{
  # prior1, prior2 and clinical.prior must be lists with dimensions alpha & beta
  tmp <- .ss.cons.binom.check.list(prior1, "prior1")
  tmp <- .ss.cons.binom.check.list(prior2, "prior2")
  tmp <- .ss.cons.binom.check.list(clinical.prior, "clinical.prior")
  
  tmp <- .ss.cons.binom.hpdlimits(accepted.pdiff, prior1, prior2, level, fast.approx=F,
                                            n.start, n.max, 
                                            clinical.prior=clinical.prior, target=prob, return.prob=T, increasing.outcome.with.n=T)

  tmp <- c(tmp, list(accepted.pdiff=accepted.pdiff, prior1=prior1, prior2=prior2, clinical.prior=clinical.prior, prob=prob, level=level, n.start=n.start, n.max=n.max))
  tmp
}
