my $file = "ConsensusBinomial.c";
my @tmp;

open(TMP, $file);
while (<TMP>)
{
  s{\r}{}g;
  s{\n}{\r\n};
  push(@tmp, $_);
}
close TMP;

my $new = "_" . $file;
open(TMP, ">$new");
foreach (@tmp)
{
  print TMP;
}
close TMP;