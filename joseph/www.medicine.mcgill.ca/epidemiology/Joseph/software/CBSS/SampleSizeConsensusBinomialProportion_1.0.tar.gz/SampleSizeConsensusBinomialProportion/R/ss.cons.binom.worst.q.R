ss.cons.binom.worst.q <-
function(quantiles, accepted.pdiff, prior1, prior2,
                                                    n.start=1000, n.max=1e7)
{
  # prior1 and prior2 must be lists with dimensions alpha & beta
  tmp <- .ss.cons.binom.check.list(prior1, "prior1")
  tmp <- .ss.cons.binom.check.list(prior2, "prior2")
  

  tmp <- .ss.cons.binom.q(quantiles, accepted.pdiff, prior1, prior2,
                                            n.start, n.max, return.worst=T)

  tmp <- c(tmp, list(quantiles=quantiles, accepted.pdiff=accepted.pdiff, prior1=prior1, prior2=prior2, n.start=n.start, n.max=n.max))
  tmp
}
