ss.cons.2binom.worst.hpdlimits <-
function(accepted.pdiff, prior1, prior2,
                                                      level=0.95, n2.n1.ratio=1, n.start=1000, n.max=100000)
{
  tmp <- .ss.cons.binom.check.list(prior1, "prior1")
  tmp <- .ss.cons.binom.check.list(prior2, "prior2")
  
  tmp <- .ss.cons.2binom.worst(accepted.pdiff, prior1, prior2, level, n.start=n.start, n.max=n.max, n2.n1.ratio=n2.n1.ratio, todo=0)  
  
  tmp <- c(tmp, list(accepted.pdiff=accepted.pdiff, prior1=prior1, prior2=prior2, 
                     level=level, n2.n1.ratio=n2.n1.ratio, n.start=n.start, n.max=n.max))

  tmp
}
