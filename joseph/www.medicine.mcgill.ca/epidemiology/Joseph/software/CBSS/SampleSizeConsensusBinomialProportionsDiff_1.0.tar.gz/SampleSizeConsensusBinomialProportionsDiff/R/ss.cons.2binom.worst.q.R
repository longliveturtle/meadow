ss.cons.2binom.worst.q <-
function(quantiles, accepted.pdiff, prior1, prior2,
                                                      n2.n1.ratio=1, n.start=1000, n.max=100000)
{
  tmp <- .ss.cons.binom.check.list(prior1, "prior1")
  tmp <- .ss.cons.binom.check.list(prior2, "prior2")
  
  tmp <- .ss.cons.2binom.worst(accepted.pdiff, prior1, prior2, quantiles, n.start=n.start, n.max=n.max, n2.n1.ratio=n2.n1.ratio, todo=2)  

  tmp <- c(tmp, list(quantiles=quantiles, accepted.pdiff=accepted.pdiff, prior1=prior1, prior2=prior2, 
                     n2.n1.ratio=n2.n1.ratio, n.start=n.start, n.max=n.max))

  tmp
}
