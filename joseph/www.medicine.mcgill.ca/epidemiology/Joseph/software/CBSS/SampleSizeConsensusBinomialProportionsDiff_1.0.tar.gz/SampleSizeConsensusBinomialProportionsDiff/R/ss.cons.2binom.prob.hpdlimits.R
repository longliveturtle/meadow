ss.cons.2binom.prob.hpdlimits <-
function(accepted.pdiff, prior1, prior2, prior1.mixture.wt=0.5, 
                                                      prob=0.5, level=.95, n2.n1.ratio=1, n.start=1000, n.max=100000, sim.size=10000, max.cons.steps.same.dir=3)
{
  tmp <- .ss.cons.binom.check.list(prior1, "prior1")
  tmp <- .ss.cons.binom.check.list(prior2, "prior2")
  
  
  tmp <- .ss.cons.2binom.hpdlimits(accepted.pdiff, prior1, prior2, level, n.start, n.max,
           sim.size=sim.size, prior1.mixture.wt=prior1.mixture.wt,
           target=prob, return.prob=T, n2.n1.ratio=n2.n1.ratio, mcs=max.cons.steps.same.dir) 

  tmp <- c(tmp, list(accepted.pdiff=accepted.pdiff, prior1=prior1, prior2=prior2, prior1.mixture.wt=prior1.mixture.wt,
                     prob=prob, level=level, n2.n1.ratio=n2.n1.ratio, n.start=n.start, n.max=n.max, sim.size=sim.size, max.cons.steps.same.dir=max.cons.steps.same.dir))

  tmp
}
