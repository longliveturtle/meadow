cdf.points <- c(0.1, 0.15)
enthusiastic.prior <- list(alpha=c(194, 200), beta=c(47, 20))
skeptical.prior    <- list(alpha=c(250, 150), beta=c(30, 50))
z <- ss.cons.2binom.worst.cdf(cdf.points, 0.2, enthusiastic.prior, skeptical.prior)

enthusiastic.prior <- list(alpha=c(194, 200), beta=c(47, 20))
skeptical.prior    <- list(alpha=c(250, 150), beta=c(30, 50))
worst.accepted.pdiff <- 0.02
z <- ss.cons.2binom.worst.hpdlimits(worst.accepted.pdiff, enthusiastic.prior, skeptical.prior)

cdf.points <- c(0.1, 0.15)
enthusiastic.prior <- list(alpha=c(194, 200), beta=c(47, 20))
skeptical.prior    <- list(alpha=c(250, 150), beta=c(30, 50))
z <- ss.cons.2binom.worst.cdf(cdf.points, 0.2, enthusiastic.prior, skeptical.prior)

cdf.points <- c(0.1, 0.15)
enthusiastic.prior <- list(alpha=c(194, 200), beta=c(47, 20))
skeptical.prior    <- list(alpha=c(250, 150), beta=c(30, 50))
z <- ss.cons.2binom.worst.cdf(cdf.points, 0.2, enthusiastic.prior, skeptical.prior)











enthusiastic.prior <- list(alpha=c(194, 200), beta=c(47, 20))
skeptical.prior    <- list(alpha=c(250, 150), beta=c(30, 50))
worst.accepted.pdiff <- 0.02
z <- ss.cons.2binom.worst.hpdlimits(worst.accepted.pdiff, enthusiastic.prior, skeptical.prior)

accepted.pdiff <- 0.01
enthusiastic.prior <- list(alpha=c(194, 200), beta=c(47, 20))
quantiles <- c(0.25, .75)
skeptical.prior    <- list(alpha=c(250, 150), beta=c(30, 50))
z <- ss.cons.2binom.worst.q(quantiles, accepted.pdiff, enthusiastic.prior, skeptical.prior)

cdf.points <- c(0.1, 0.15)
enthusiastic.prior <- list(alpha=c(194, 200), beta=c(47, 20))
skeptical.prior    <- list(alpha=c(250, 150), beta=c(30, 50))
z <- ss.cons.2binom.worst.cdf(cdf.points, 0.2, enthusiastic.prior, skeptical.prior)

enthusiastic.prior <- list(alpha=c(194, 200), beta=c(47, 20))
skeptical.prior    <- list(alpha=c(250, 150), beta=c(30, 50))
worst.accepted.pdiff <- 0.02
z <- ss.cons.2binom.worst.hpdlimits(worst.accepted.pdiff, enthusiastic.prior, skeptical.prior)

accepted.pdiff <- 0.01
enthusiastic.prior <- list(alpha=c(194, 200), beta=c(47, 20))
quantiles <- c(0.25, .75)
skeptical.prior    <- list(alpha=c(250, 150), beta=c(30, 50))
z <- ss.cons.2binom.worst.q(quantiles, accepted.pdiff, enthusiastic.prior, skeptical.prior)