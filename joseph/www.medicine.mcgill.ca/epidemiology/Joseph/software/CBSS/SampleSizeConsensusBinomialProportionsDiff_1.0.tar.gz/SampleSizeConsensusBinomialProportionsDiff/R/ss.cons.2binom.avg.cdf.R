ss.cons.2binom.avg.cdf <-
function(cdf.points, accepted.cdf.diff, prior1, prior2, 
                                                      prior1.mixture.wt=0.5, n2.n1.ratio=1, n.start=1000, n.max=100000, sim.size=10000, max.cons.steps.same.dir=3)
{
  tmp <- .ss.cons.binom.check.list(prior1, "prior1")
  tmp <- .ss.cons.binom.check.list(prior2, "prior2")
  
  
  tmp <- .ss.cons.2binom.cdf(cdf.points, accepted.cdf.diff, prior1, prior2, n.start, n.max,
           sim.size=sim.size, prior1.mixture.wt=prior1.mixture.wt,
           target=accepted.cdf.diff, n2.n1.ratio=n2.n1.ratio, mcs=max.cons.steps.same.dir)

  tmp <- c(tmp, list(cdf.points=cdf.points, accepted.cdf.diff=accepted.cdf.diff, prior1=prior1, prior2=prior2, prior1.mixture.wt=prior1.mixture.wt, 
                     n2.n1.ratio=n2.n1.ratio, n.start=n.start, n.max=n.max, sim.size=sim.size, max.cons.steps.same.dir=max.cons.steps.same.dir))

  tmp
}
