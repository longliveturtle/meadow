ss.cons.2binom.avg.hpdlimits.bothmarg <-
function(accepted.pdiff, prior1, prior2, 
                                                      level=0.95, n2.n1.ratio=1, n.start=1000, n.max=100000, sim.size=10000, max.cons.steps.same.dir=3)
{
  tmp <- .ss.cons.binom.check.list(prior1, "prior1")
  tmp <- .ss.cons.binom.check.list(prior2, "prior2")
  
  
  tmp <- .ss.cons.2binom.hpdlimits(accepted.pdiff, prior1, prior2, level, n.start, n.max, sim.size=sim.size, 
           target=accepted.pdiff, n2.n1.ratio=n2.n1.ratio, mcs=max.cons.steps.same.dir, both=T) 

  tmp <- c(tmp, list(accepted.pdiff=accepted.pdiff, prior1=prior1, prior2=prior2, 
                     level=level, n2.n1.ratio=n2.n1.ratio, n.start=n.start, n.max=n.max, sim.size=sim.size, max.cons.steps.same.dir=max.cons.steps.same.dir))

  tmp
}
